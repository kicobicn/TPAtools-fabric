package com.kicobicn;

import com.kicobicn.command.*;
import com.kicobicn.config.ModConfigs;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TPATools implements ModInitializer {
	public static final String MODID = "tpatools";
	public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

	@Override
	public void onInitialize() {
		LOGGER.info("TPATools mod is initializing...");

		// Register commands
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			TPAHandler.registerCommands(dispatcher, registryAccess, environment);
			HomeHandler.registerCommands(dispatcher, registryAccess, environment);
			GraveHandler.registerCommands(dispatcher, registryAccess, environment);
			BackHandler.registerCommands(dispatcher, registryAccess, environment);
			ModConfigs.registerCommands(dispatcher, registryAccess, environment);
		});

		// Register server lifecycle events
		ServerLifecycleEvents.SERVER_STARTING.register(this::onServerStarting);
		ServerLifecycleEvents.SERVER_STOPPING.register(this::onServerStopping);

		// Register server tick event
		ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);

		// Register chat event
		ServerMessageEvents.ALLOW_CHAT_MESSAGE.register(new ChatHandler());

		// Initialize configs
		ModConfigs.initializeConfig(FabricLoader.getInstance().getConfigDir());
	}

	private void onServerStarting(MinecraftServer server) {
		TPAHandler.onServerStarting(server);
		HomeHandler.loadHomes();
		GraveHandler.loadGraves();
		TPAHandler.loadToggleStates();
		TPAHandler.loadLockedPlayers();
		TPAHandler.loadCommandPermissions();
	}

	private void onServerStopping(MinecraftServer server) {
		HomeHandler.saveHomes();
		GraveHandler.saveGraves();
		TPAHandler.saveToggleStates();
		TPAHandler.saveLockedPlayers();
		TPAHandler.saveCommandPermissions();
	}

	private void onServerTick(MinecraftServer server) {
		TPAHandler.tick();
	}
}