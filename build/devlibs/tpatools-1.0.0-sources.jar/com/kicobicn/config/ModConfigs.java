package com.kicobicn.config;

import com.google.gson.Gson;
import com.kicobicn.command.TPAHandler;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class ModConfigs {
    private static final Logger LOGGER = LogManager.getLogger("TPATools");

    // Configuration values
    public static long COOLDOWN_TIME = 3 * 1000L; // 3 seconds in milliseconds
    public static int TIMEOUT_TICKS = 30 * 20; // 30 seconds in ticks
    public static String DEFAULT_LANGUAGE = "zh_cn";
    public static int MAX_HOMES = 2;
    public static int COOLDOWN_SECONDS = 60;
    public static int WAIT_SECONDS = 30;
    public static boolean DEBUG_MODE = false;

    // Translations map
    public static final Map<String, String> translations = new HashMap<>();

    // Command permissions
    public static final Map<String, Boolean> commandPermissions = new HashMap<>();

    // Configuration directory
    private static Path configDir;

    public static Path getConfigDir() {
        return configDir;
    }

    public static void initializeConfig(Path configPath) {
        configDir = configPath.resolve("tpatools");
        try {
            if (!Files.exists(configDir)) {
                Files.createDirectories(configDir);
                DebugLog.info("Created config directory: {}", configDir.toString());
            }
        } catch (IOException e) {
            DebugLog.error("Failed to create config directory: {}", e.getMessage());
        }
    }

    public static boolean checkCommandPermission(CommandSourceStack source, String command) {
        boolean needOp = commandPermissions.getOrDefault(command, false);
        if (needOp) {
            return source.hasPermission(2); // Need OP permission
        } else {
            return true; // No OP permission needed, all players can use
        }
    }

    // Tab completion providers
    private static final SuggestionProvider<CommandSourceStack> COMMAND_SUGGESTIONS = (context, builder) -> {
        String[] commands = {"tpa", "home", "grave", "back"};
        for (String cmd : commands) {
            builder.suggest(cmd);
        }
        return CompletableFuture.completedFuture(builder.build());
    };

    private static final SuggestionProvider<CommandSourceStack> BOOLEAN_SUGGESTIONS = (context, builder) -> {
        builder.suggest("true");
        builder.suggest("false");
        return CompletableFuture.completedFuture(builder.build());
    };

    private static final SuggestionProvider<CommandSourceStack> TIME_SUGGESTIONS = (context, builder) -> {
        String[] times = {"10", "30", "60", "120", "300"};
        for (String time : times) {
            builder.suggest(time);
        }
        return CompletableFuture.completedFuture(builder.build());
    };

    // Debug logging
    public static boolean isDebugEnabled() {
        return DEBUG_MODE;
    }

    public static class DebugLog {
        public static void info(String message, Object... args) {
            if (isDebugEnabled()) {
                LOGGER.info("[DEBUG INFO] " + message, args);
            }
        }

        public static void warn(String message, Object... args) {
            if (isDebugEnabled()) {
                LOGGER.warn("[DEBUG WARN] " + message, args);
            }
        }

        public static void error(String message, Object... args) {
            if (isDebugEnabled()) {
                LOGGER.error("[DEBUG ERROR] " + message, args);
            }
        }

        public static void log(String message, Object... args) {
            info(message, args);
        }
    }

    // Initialize command permissions
    public static void initCommandPermissions() {
        commandPermissions.putIfAbsent("tpa", false);
        commandPermissions.putIfAbsent("home", false);
        commandPermissions.putIfAbsent("grave", false);
        commandPermissions.putIfAbsent("back", false);
        commandPermissions.putIfAbsent("debug", false);
    }

    // Supported languages
    private static final Set<String> SUPPORTED_LANGUAGES = Set.of("en_us", "zh_cn");

    public static void loadTranslations(String lang) {
        translations.clear();
        String fileName = String.format("%s.json", lang);

        LOGGER.info("Attempting to load language file for '{}'", lang);

        try {
            Path langPath = FabricLoader.getInstance().getModContainer("tpatools")
                    .orElseThrow(() -> new RuntimeException("Mod container not found"))
                    .getPath("assets/tpatools/lang/" + fileName);

            if (Files.exists(langPath)) {
                try (BufferedReader reader = Files.newBufferedReader(langPath, StandardCharsets.UTF_8)) {
                    java.util.Map<String, String> json = new Gson().fromJson(reader, java.util.Map.class);
                    translations.putAll(json);
                    LOGGER.info("Loaded language from: assets/tpatools/lang/{}", fileName);
                }
            } else {
                LOGGER.debug("Language file not found: assets/tpatools/lang/{}", fileName);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to load language file for '{}': {}", lang, e.getMessage());
        }
    }

    public static MutableComponent translateWithFallback(String key, String fallback, Object... args) {
        String translated = translations.getOrDefault(key, fallback);
        // Check if there are arguments to process
        if (args.length == 0) {
            return Component.literal(translated);
        }
        Object[] stringArgs = new Object[args.length];
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof Component component) {
                stringArgs[i] = component.getString();
            } else {
                stringArgs[i] = args[i];
            }
        }
        try {
            return Component.literal(String.format(translated, stringArgs));
        } catch (Exception e) {
            // If formatting fails, return the raw translation with args as strings
            ModConfigs.DebugLog.error("Error formatting translation for key '{}': {}", key, e.getMessage());
            StringBuilder sb = new StringBuilder(translated);
            for (Object arg : args) {
                sb.append(" ").append(arg != null ? arg.toString() : "null");
            }
            return Component.literal(sb.toString());
        }
    }

    // Register tpatools management commands
    public static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext registryAccess, Commands.CommandSelection environment) {
        dispatcher.register(
                Commands.literal("tpatools")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.literal("setlanguage")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("lang", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            for (String lang : SUPPORTED_LANGUAGES) {
                                                builder.suggest(lang);
                                            }
                                            return CompletableFuture.completedFuture(builder.build());
                                        })
                                        .executes(context -> {
                                            String lang = StringArgumentType.getString(context, "lang");
                                            if (!SUPPORTED_LANGUAGES.contains(lang)) {
                                                context.getSource().sendFailure(
                                                        translateWithFallback(
                                                                "command.tpatool.setlanguage.invalid",
                                                                "Invalid language. Available: en_us, zh_cn"
                                                        )
                                                );
                                                return 0;
                                            }

                                            DEFAULT_LANGUAGE = lang;
                                            loadTranslations(lang);

                                            context.getSource().sendSuccess(
                                                    () -> translateWithFallback(
                                                            "command.tpatool.setlanguage.success",
                                                            "Language set to %s.",
                                                            lang
                                                    ),
                                                    true
                                            );

                                            LOGGER.info("Language switched to {}", lang);
                                            return 1;
                                        })
                                ))
                        .then(Commands.literal("setmaxhome")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, Integer>argument("count", IntegerArgumentType.integer(1))
                                        .executes(context -> {
                                            int count = IntegerArgumentType.getInteger(context, "count");
                                            MAX_HOMES = count;
                                            context.getSource().sendSuccess(
                                                    () -> translateWithFallback("command.tpatool.setmaxhome.success", "Maximum homes set to %s.", count),
                                                    true
                                            );
                                            DebugLog.info("Max homes set to {} by {}", count, context.getSource().getDisplayName().getString());
                                            return 1;
                                        })))
                        .then(Commands.literal("needop")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("command", StringArgumentType.string())
                                        .suggests(COMMAND_SUGGESTIONS)
                                        .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("enable", StringArgumentType.string())
                                                .suggests(BOOLEAN_SUGGESTIONS)
                                                .executes(context -> {
                                                    String command = StringArgumentType.getString(context, "command");
                                                    String enableStr = StringArgumentType.getString(context, "enable");
                                                    boolean enable = enableStr.equalsIgnoreCase("true");
                                                    if (!Arrays.asList("tpa", "home", "grave", "back").contains(command)) {
                                                        context.getSource().sendFailure(
                                                                translateWithFallback("command.tpatool.needop.invalid_command", "Invalid command. Use 'tpa', 'home', 'grave', or 'back'.")
                                                        );
                                                        return 0;
                                                    }
                                                    commandPermissions.put(command, enable);
                                                    TPAHandler.saveCommandPermissions();
                                                    context.getSource().sendSuccess(
                                                            () -> translateWithFallback(
                                                                    enable ? "command.tpatool.needop.success_enabled" : "command.tpatool.needop.success_disabled",
                                                                    enable ? "%s commands now require OP permission." : "%s commands now do not require OP permission.",
                                                                    command
                                                            ),
                                                            true
                                                    );
                                                    DebugLog.info("{} commands set to {} OP by {}", command, enable ? "require" : "not require", context.getSource().getDisplayName().getString());
                                                    return 1;
                                                }))))
                        .then(Commands.literal("tpacdtime")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, Integer>argument("time", IntegerArgumentType.integer(0))
                                        .suggests(TIME_SUGGESTIONS)
                                        .executes(context -> {
                                            int time = IntegerArgumentType.getInteger(context, "time");
                                            COOLDOWN_TIME = (long) time * 1000; // Convert to milliseconds
                                            context.getSource().sendSuccess(
                                                    () -> translateWithFallback(
                                                            "command.tpatool.tpacdtime.success",
                                                            "TPA cooldown time set to %d seconds.",
                                                            time
                                                    ),
                                                    true
                                            );
                                            DebugLog.info("TPA cooldown time set to {} seconds by {}",
                                                    time, context.getSource().getDisplayName().getString());
                                            return 1;
                                        })))
                        .then(Commands.literal("tpawaittime")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, Integer>argument("time", IntegerArgumentType.integer(0))
                                        .suggests(TIME_SUGGESTIONS)
                                        .executes(context -> {
                                            int time = IntegerArgumentType.getInteger(context, "time");
                                            TIMEOUT_TICKS = time * 20; // Convert to ticks (1 second=20ticks)
                                            context.getSource().sendSuccess(
                                                    () -> translateWithFallback(
                                                            "command.tpatool.tpawaittime.success",
                                                            "TPA wait time set to %d seconds.",
                                                            time
                                                    ),
                                                    true
                                            );
                                            DebugLog.info("TPA wait time set to {} seconds by {}",
                                                    time, context.getSource().getDisplayName().getString());
                                            return 1;
                                        })))
                        .then(Commands.literal("debug")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("enable", StringArgumentType.string())
                                        .suggests(BOOLEAN_SUGGESTIONS)
                                        .executes(context -> {
                                            String enableStr = StringArgumentType.getString(context, "enable");
                                            boolean enable = enableStr.equalsIgnoreCase("true");
                                            DEBUG_MODE = enable;
                                            context.getSource().sendSuccess(
                                                    () -> translateWithFallback(
                                                            enable ? "command.tpatool.debug.enabled" : "command.tpatool.debug.disabled",
                                                            enable ? "Debug mode enabled." : "Debug mode disabled."
                                                    ),
                                                    true
                                            );
                                            DebugLog.info("Debug mode {} by {}", enable ? "enabled" : "disabled", context.getSource().getDisplayName().getString());
                                            return 1;
                                        }))
                                .executes(context -> {
                                    boolean currentState = DEBUG_MODE;
                                    context.getSource().sendSuccess(
                                            () -> translateWithFallback(
                                                    "command.tpatool.debug.status",
                                                    "Debug mode is currently %s.",
                                                    currentState ? "enabled" : "disabled"
                                            ),
                                            true
                                    );
                                    return 1;
                                }))
        );
    }
}
