package com.kicobicn.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kicobicn.config.ModConfigs;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class HomeHandler {
    private static final Map<UUID, Map<String, Home>> playerHomes = new HashMap<>();
    private static final Map<String, Map<String, PublicHomeInfo>> publicHomesByOwner = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // PublicHomeInfo class to store public home UUID and username
    private static class PublicHomeInfo {
        public UUID ownerUUID;
        public String ownerName;
        public String homeName;

        public PublicHomeInfo(UUID ownerUUID, String ownerName, String homeName) {
            this.ownerUUID = ownerUUID;
            this.ownerName = ownerName;
            this.homeName = homeName;
        }
    }

    // Store last position mapping
    private static final Map<UUID, Home.Position> lastPositions = new HashMap<>();

    public static class Home {
        public static class Position {
            public double x, y, z;
            public float xRot, yRot;
            public ResourceLocation dimension;

            public Position(double x, double y, double z, float xRot, float yRot, ResourceLocation dimension) {
                this.x = x; this.y = y; this.z = z;
                this.xRot = xRot; this.yRot = yRot; this.dimension = dimension;
            }
        }

        public Position position;
        public List<UUID> sharedPlayers;

        public Home(Position position, List<UUID> sharedPlayers) {
            this.position = position;
            this.sharedPlayers = sharedPlayers != null ? sharedPlayers : new ArrayList<>();
        }
    }

    private static void recordLastPosition(ServerPlayer player) {
        ResourceLocation dimension = player.level().dimension().location();
        lastPositions.put(player.getUUID(), new Home.Position(
                player.getX(), player.getY(), player.getZ(),
                player.getXRot(), player.getYRot(), dimension
        ));
    }

    public static void loadHomes() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_homes.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Object> data = GSON.fromJson(jsonContent, java.util.Map.class);
                playerHomes.clear();
                publicHomesByOwner.clear();

                if (data != null) {
                    // Load playerHomes
                    if (data.containsKey("playerHomes")) {
                        java.util.Map<String, Object> homesData = (java.util.Map<String, Object>) data.get("playerHomes");
                        if (homesData != null) {
                            for (java.util.Map.Entry<String, Object> entry : homesData.entrySet()) {
                                UUID playerUUID = UUID.fromString(entry.getKey());
                                java.util.Map<String, Object> playerHomesData = (java.util.Map<String, Object>) entry.getValue();
                                
                                Map<String, Home> playerHomeMap = new HashMap<>();
                                for (java.util.Map.Entry<String, Object> homeEntry : playerHomesData.entrySet()) {
                                    String homeName = homeEntry.getKey();
                                    java.util.Map<String, Object> homeData = (java.util.Map<String, Object>) homeEntry.getValue();
                                    
                                    // Process position
                                    java.util.Map<String, Object> positionData = (java.util.Map<String, Object>) homeData.get("position");
                                    if (positionData != null) {
                                        double x = ((Double) positionData.get("x")).doubleValue();
                                        double y = ((Double) positionData.get("y")).doubleValue();
                                        double z = ((Double) positionData.get("z")).doubleValue();
                                        float xRot = ((Double) positionData.get("xRot")).floatValue();
                                        float yRot = ((Double) positionData.get("yRot")).floatValue();
                                        String dimensionStr = (String) positionData.get("dimension");
                                        
                                        Home.Position pos = new Home.Position(x, y, z, xRot, yRot, new ResourceLocation(dimensionStr));
                                        
                                        // Process sharedPlayers
                                        List<UUID> sharedPlayers = new ArrayList<>();
                                        java.util.List<Object> sharedPlayersData = (java.util.List<Object>) homeData.get("sharedPlayers");
                                        if (sharedPlayersData != null) {
                                            for (Object obj : sharedPlayersData) {
                                                sharedPlayers.add(UUID.fromString(obj.toString()));
                                            }
                                        }
                                        
                                        playerHomeMap.put(homeName, new Home(pos, sharedPlayers));
                                    }
                                }
                                playerHomes.put(playerUUID, playerHomeMap);
                            }
                        }
                    }

                    // Load publicHomesByOwner
                    if (data.containsKey("publicHomesByOwner")) {
                        java.util.Map<String, Object> publicHomesData = (java.util.Map<String, Object>) data.get("publicHomesByOwner");
                        if (publicHomesData != null) {
                            for (java.util.Map.Entry<String, Object> entry : publicHomesData.entrySet()) {
                                String ownerUUID = entry.getKey();
                                java.util.Map<String, Object> ownerHomesData = (java.util.Map<String, Object>) entry.getValue();
                                
                                Map<String, PublicHomeInfo> ownerHomesMap = new HashMap<>();
                                for (java.util.Map.Entry<String, Object> homeEntry : ownerHomesData.entrySet()) {
                                    String homeName = homeEntry.getKey();
                                    java.util.Map<String, Object> homeInfoData = (java.util.Map<String, Object>) homeEntry.getValue();
                                    
                                    String ownerUUIDStr = (String) homeInfoData.get("ownerUUID");
                                    String ownerName = (String) homeInfoData.get("ownerName");
                                    
                                    ownerHomesMap.put(homeName, new PublicHomeInfo(
                                            UUID.fromString(ownerUUIDStr),
                                            ownerName,
                                            homeName
                                    ));
                                }
                                publicHomesByOwner.put(ownerUUID, ownerHomesMap);
                            }
                        }
                    }

                    ModConfigs.DebugLog.info("Loaded homes and public homes from {}", path.toString());
                }
            }
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to load homes: {}", e.getMessage());
        } catch (Exception e) {
            ModConfigs.DebugLog.error("Error parsing home data: {}", e.getMessage());
        }
    }

    public static void saveHomes() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_homes.json");

            java.util.Map<String, Object> data = new java.util.HashMap<>();
            data.put("playerHomes", playerHomes);

            // Public homes save format
            java.util.Map<String, Object> publicHomesData = new java.util.HashMap<>();
            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUID = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> homes = ownerEntry.getValue();
                publicHomesData.put(ownerUUID, homes);
            }
            data.put("publicHomesByOwner", publicHomesData);

            Files.writeString(path, GSON.toJson(data));
            ModConfigs.DebugLog.info("Saved homes and public homes to {}", path.toString());
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to save homes: {}", e.getMessage());
        }
    }

    // Tab completion: player's own homes
    private static final SuggestionProvider<CommandSourceStack> OWN_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();
            Map<String, Home> homes = playerHomes.get(player.getUUID());
            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: public homes
    private static final SuggestionProvider<CommandSourceStack> PUBLIC_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());

            if (ownerPublicHomes != null) {
                for (String homeName : ownerPublicHomes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: non-public homes
    private static final SuggestionProvider<CommandSourceStack> NON_PUBLIC_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();
            Map<String, Home> homes = playerHomes.get(player.getUUID());
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());

            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    // Check if home is not public
                    if (ownerPublicHomes == null || !ownerPublicHomes.containsKey(homeName)) {
                        builder.suggest(homeName);
                    }
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: accessible homes (own)
    private static final SuggestionProvider<CommandSourceStack> ACCESSIBLE_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();
            Map<String, Home> homes = playerHomes.get(player.getUUID());
            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            ModConfigs.DebugLog.error("Failed to provide suggestions for /home tp: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: /home otherhome playername:homename
    private static final SuggestionProvider<CommandSourceStack> OTHER_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();

            // Handle public homes
            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUIDStr = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> ownerHomes = ownerEntry.getValue();

                UUID ownerUUID = UUID.fromString(ownerUUIDStr);
                String ownerName = player.getServer().getProfileCache().get(ownerUUID)
                        .map(GameProfile::getName).orElse("Unknown");

                for (String homeName : ownerHomes.keySet()) {
                    builder.suggest(ownerName + ":" + homeName);
                }
            }

            // Handle private shared homes
            for (java.util.Map.Entry<UUID, Map<String, Home>> entry : playerHomes.entrySet()) {
                UUID ownerUUID = entry.getKey();
                if (!ownerUUID.equals(player.getUUID())) {
                    String ownerName = player.getServer().getProfileCache().get(ownerUUID)
                            .map(GameProfile::getName).orElse("Unknown");
                    for (java.util.Map.Entry<String, Home> homeEntry : entry.getValue().entrySet()) {
                        if (homeEntry.getValue().sharedPlayers.contains(player.getUUID())) {
                            builder.suggest(ownerName + ":" + homeEntry.getKey());
                        }
                    }
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            ModConfigs.DebugLog.error("Failed to provide suggestions for /home otherhome: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: /home sharelist in/out parameter
    private static final SuggestionProvider<CommandSourceStack> SHARELIST_SUGGESTIONS = (context, builder) -> {
        builder.suggest("in");
        builder.suggest("out");
        return CompletableFuture.completedFuture(builder.build());
    };

    // Tab completion: player names for /home unshare (support offline players)
    private static final SuggestionProvider<CommandSourceStack> PLAYER_NAME_SUGGESTIONS = (context, builder) -> {
        try {
            ServerPlayer player = context.getSource().getPlayerOrException();
            MinecraftServer server = player.getServer();
            if (server != null) {
                // Get all UUIDs from playerHomes and convert to player names
                for (UUID uuid : playerHomes.keySet()) {
                    server.getProfileCache().get(uuid)
                            .map(GameProfile::getName)
                            .ifPresent(builder::suggest);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            ModConfigs.DebugLog.error("Failed to provide player name suggestions: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    public static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext registryAccess, Commands.CommandSelection environment) {
        dispatcher.register(
                Commands.literal("home")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "home"))
                        .then(Commands.literal("tp")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(ACCESSIBLE_HOME_SUGGESTIONS)
                                        .executes(context -> teleportToHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "name")))))
                        .then(Commands.literal("set")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .executes(context -> setHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "name")))))
                        .then(Commands.literal("list")
                                .executes(context -> listHomes(context.getSource().getPlayerOrException())))
                        .then(Commands.literal("remove")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .executes(context -> removeHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "name")))))
                        .then(Commands.literal("rename")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("newName", StringArgumentType.string())
                                                .executes(context -> renameHome(
                                                        context.getSource().getPlayerOrException(),
                                                        StringArgumentType.getString(context, "name"),
                                                        StringArgumentType.getString(context, "newName")
                                                )))))
                        .then(Commands.literal("share")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                                                                                                                                                                                        .then(Commands.argument("player", EntityArgument.player())
                                                .executes(context -> shareHome(
                                                        context.getSource().getPlayerOrException(),
                                                        StringArgumentType.getString(context, "name"),
                                                        EntityArgument.getPlayer(context, "player")
                                                )))))
                        .then(Commands.literal("public")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(NON_PUBLIC_HOME_SUGGESTIONS)
                                        .executes(context -> setPublicHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "name")))))
                        .then(Commands.literal("private")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(PUBLIC_HOME_SUGGESTIONS)
                                        .executes(context -> setPrivateHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "name")))))
                        .then(Commands.literal("otherhome")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("home", StringArgumentType.greedyString())
                                        .suggests(OTHER_HOME_SUGGESTIONS)
                                        .executes(context -> teleportToOtherHome(context.getSource().getPlayerOrException(), StringArgumentType.getString(context, "home")))))
                        .then(Commands.literal("otherlist")
                                .executes(context -> listOtherHomes(context.getSource().getPlayerOrException())))
                        .then(Commands.literal("sharelist")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("type", StringArgumentType.string())
                                        .suggests(SHARELIST_SUGGESTIONS)
                                        .executes(context -> shareList(
                                                context.getSource().getPlayerOrException(),
                                                StringArgumentType.getString(context, "type")
                                        ))))
                        .then(Commands.literal("unshare")
                                .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .executes(context -> unshareHome(
                                                context.getSource().getPlayerOrException(),
                                                StringArgumentType.getString(context, "name"),
                                                null,
                                                null
                                        ))
                                        .then(RequiredArgumentBuilder.<CommandSourceStack, String>argument("player", StringArgumentType.string())
                                                .suggests(PLAYER_NAME_SUGGESTIONS)
                                                .executes(context -> unshareHome(
                                                        context.getSource().getPlayerOrException(),
                                                        StringArgumentType.getString(context, "name"),
                                                        StringArgumentType.getString(context, "player"),
                                                        context.getSource()
                                                )))))
        );
    }

    private static int setHome(ServerPlayer player, String homeName) {
        Map<String, Home> homes = playerHomes.computeIfAbsent(player.getUUID(), k -> new HashMap<>());
        if (homes.size() >= ModConfigs.MAX_HOMES) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.limit_exceeded", "You have reached the maximum number of homes (%s)!", ModConfigs.MAX_HOMES
            ));
            return 0;
        }
        if (homes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.name_exists", "A home named %s already exists!", homeName
            ));
            return 0;
        }
        ResourceLocation dimension = player.level().dimension().location();
        Home.Position position = new Home.Position(
                player.getX(), player.getY(), player.getZ(),
                player.getXRot(), player.getYRot(), dimension
        );
        homes.put(homeName, new Home(position, new ArrayList<>()));
        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.set", "Home %s set at your current position.", homeName
        ));
        ModConfigs.DebugLog.info("Player {} set home {} at {}", player.getName().getString(), homeName, dimension);
        return 1;
    }

    private static int teleportToHome(ServerPlayer player, String name) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes != null && homes.containsKey(name)) {
            Home home = homes.get(name);
            ServerLevel level = player.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, home.position.dimension));
            if (level == null) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_dimension", "Invalid dimension for home %s!", name
                ));
                return 0;
            }
            BackHandler.recordPosition(player);
            player.teleportTo(level, home.position.x, home.position.y, home.position.z,
                    home.position.yRot, home.position.xRot);
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.teleported", "Teleported to home %s.", name
            ));
            ModConfigs.DebugLog.info("Player {} teleported to home {} at dimension={}, x={}, y={}, z={}",
                    player.getName().getString(), name, home.position.dimension,
                    home.position.x, home.position.y, home.position.z);
            return 1;
        }
        return teleportToOtherHome(player, name); // Try to handle as other's home
    }

    private static int listHomes(ServerPlayer player) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || homes.isEmpty()) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.list_empty", "You have no homes set."
            ));
            return 0;
        }
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.list", "Your homes:"
        ));
        for (java.util.Map.Entry<String, Home> entry : homes.entrySet()) {
            Home home = entry.getValue();
            player.sendSystemMessage(Component.literal(String.format(
                    "- %s: %s (x=%.2f, y=%.2f, z=%.2f)",
                    entry.getKey(), home.position.dimension, home.position.x, home.position.y, home.position.z
            )));
        }
        return 1;
    }

    private static int shareList(ServerPlayer player, String type) {
        try {
            if (!type.equals("in") && !type.equals("out")) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.invalid_type", "Invalid type! Use 'in' or 'out'."
                ));
                return 0;
            }
            if (type.equals("in")) {
                boolean found = false;
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.in", "Homes shared with you:"
                ));
                for (java.util.Map.Entry<UUID, Map<String, Home>> entry : playerHomes.entrySet()) {
                    UUID ownerUUID = entry.getKey();
                    String ownerName = player.getServer().getProfileCache().get(ownerUUID)
                            .map(GameProfile::getName).orElse("Unknown");
                    for (java.util.Map.Entry<String, Home> homeEntry : entry.getValue().entrySet()) {
                        String homeName = homeEntry.getKey();
                        Home home = homeEntry.getValue();
                        if (home.sharedPlayers.contains(player.getUUID())) {
                            String dimensionName = home.position.dimension != null
                                    ? home.position.dimension.toString()
                                    : "unknown";
                            player.sendSystemMessage(Component.literal(String.format(
                                    "- %s (%s): %s (x=%.2f, y=%.2f, z=%.2f)",
                                    homeName, ownerName, dimensionName,
                                    home.position.x, home.position.y, home.position.z
                            )));
                            found = true;
                        }
                    }
                }
                if (!found) {
                    player.sendSystemMessage(ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.in_empty", "No homes are shared with you."
                    ));
                    return 0;
                }
                return 1;
            } else {
                Map<String, Home> homes = playerHomes.get(player.getUUID());
                if (homes == null || homes.isEmpty()) {
                    player.sendSystemMessage(ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.out_empty", "You have not shared any homes."
                    ));
                    return 0;
                }
                boolean found = false;
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.out", "Homes you have shared:"
                ));
                for (java.util.Map.Entry<String, Home> homeEntry : homes.entrySet()) {
                    String homeName = homeEntry.getKey();
                    Home home = homeEntry.getValue();
                    if (!home.sharedPlayers.isEmpty()) {
                        List<String> sharedPlayerNames = new ArrayList<>();
                        for (UUID sharedUUID : home.sharedPlayers) {
                            String playerName = player.getServer().getProfileCache().get(sharedUUID)
                                    .map(GameProfile::getName).orElse("Unknown");
                            sharedPlayerNames.add(playerName);
                        }
                        String dimensionName = home.position.dimension != null
                                ? home.position.dimension.toString()
                                : "unknown";
                        player.sendSystemMessage(Component.literal(String.format(
                                "- %s: Shared with %s (%s, x=%.2f, y=%.2f, z=%.2f)",
                                homeName, String.join(", ", sharedPlayerNames),
                                dimensionName, home.position.x, home.position.y, home.position.z
                        )));
                        found = true;
                    }
                }
                if (!found) {
                    player.sendSystemMessage(ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.out_empty", "You have not shared any homes."
                    ));
                    return 0;
                }
                return 1;
            }
        } catch (Exception e) {
            ModConfigs.DebugLog.error("Error executing /home sharelist {}: {}", type, e.getMessage());
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }

    private static int removeHome(ServerPlayer player, String name) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(name)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", name
            ));
            return 0;
        }

        homes.remove(name);

        // Also remove from public homes list
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());
        if (ownerPublicHomes != null) {
            ownerPublicHomes.remove(name);
            if (ownerPublicHomes.isEmpty()) {
                publicHomesByOwner.remove(player.getUUID().toString());
            }
        }

        if (homes.isEmpty()) {
            playerHomes.remove(player.getUUID());
        }

        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.removed", "Home %s removed.", name
        ));
        ModConfigs.DebugLog.info("Player {} removed home {}", player.getName().getString(), name);
        return 1;
    }

    private static int renameHome(ServerPlayer player, String oldName, String newName) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(oldName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", oldName
            ));
            return 0;
        }
        if (homes.containsKey(newName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.name_exists", "A home named %s already exists!", newName
            ));
            return 0;
        }

        Home home = homes.remove(oldName);
        homes.put(newName, home);

        // Update name in public homes list if this home is public
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());
        if (ownerPublicHomes != null && ownerPublicHomes.containsKey(oldName)) {
            PublicHomeInfo info = ownerPublicHomes.remove(oldName);
            ownerPublicHomes.put(newName, new PublicHomeInfo(info.ownerUUID, info.ownerName, newName));
        }

        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.renamed", "Home %s renamed to %s.", oldName, newName
        ));
        ModConfigs.DebugLog.info("Player {} renamed home {} to {}", player.getName().getString(), oldName, newName);
        return 1;
    }

    private static int shareHome(ServerPlayer player, String name, ServerPlayer target) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(name)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", name
            ));
            return 0;
        }
        Home home = homes.get(name);
        if (home.sharedPlayers.contains(target.getUUID())) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.already_shared", "Home %s is already shared with %s!", name, target.getName()
            ));
            return 0;
        }
        home.sharedPlayers.add(target.getUUID());
        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.shared", "Home %s shared with %s.", name, target.getName()
        ));
        target.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.shared_received", "%s shared their home %s with you.", player.getName(), name
        ));
        ModConfigs.DebugLog.info("Player {} shared home {} with {}", player.getName().getString(), name, target.getName().getString());
        return 1;
    }

    // unshareHome method
    private static int unshareHome(ServerPlayer player, String homeName, String targetPlayerName, CommandSourceStack source) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }
        Home home = homes.get(homeName);
        if (targetPlayerName == null) {
            if (home.sharedPlayers.isEmpty()) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.no_players", "Home %s is not shared with anyone!", homeName
                ));
                return 0;
            }
            home.sharedPlayers.clear();
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.unshare.all", "Removed sharing of home %s for all players.", homeName
            ));
            saveHomes();
            return 1;
        } else {
            MinecraftServer server = player.getServer();
            Optional<GameProfile> profile = server.getProfileCache().get(targetPlayerName);
            if (profile.isEmpty()) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.player_not_found", "Player %s not found!", targetPlayerName
                ));
                return 0;
            }
            UUID targetUUID = profile.get().getId();
            if (!home.sharedPlayers.contains(targetUUID)) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.not_shared", "Home %s is not shared with %s!", homeName, targetPlayerName
                ));
                return 0;
            }
            home.sharedPlayers.remove(targetUUID);
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.unshare.player", "Removed sharing of home %s with %s.", homeName, targetPlayerName
            ));
            ServerPlayer targetPlayer = server.getPlayerList().getPlayer(targetUUID);
            if (targetPlayer != null) {
                targetPlayer.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.notify", "%s has removed sharing of their home %s with you.", player.getName().getString(), homeName
                ));
            }
            saveHomes();
            return 1;
        }
    }

    private static int setPublicHome(ServerPlayer player, String homeName) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }

        // Check if already public
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());
        if (ownerPublicHomes != null && ownerPublicHomes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.already_public", "Home %s is already public!", homeName
            ));
            return 0;
        }

        // Add public home info
        String ownerName = player.getName().getString();
        PublicHomeInfo info = new PublicHomeInfo(player.getUUID(), ownerName, homeName);

        // Use player UUID as outer key, home name as inner key
        publicHomesByOwner.computeIfAbsent(player.getUUID().toString(), k -> new java.util.HashMap<>())
                .put(homeName, info);

        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.publicized", "Home %s is now public.", homeName
        ));
        ModConfigs.DebugLog.info("Player {} set home {} as public.", player.getName().getString(), homeName);
        return 1;
    }

    private static int setPrivateHome(ServerPlayer player, String homeName) {
        Map<String, Home> homes = playerHomes.get(player.getUUID());
        if (homes == null || !homes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }

        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.getUUID().toString());
        if (ownerPublicHomes == null || !ownerPublicHomes.containsKey(homeName)) {
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_public", "Home %s is not public!", homeName
            ));
            return 0;
        }

        // Remove public home info
        ownerPublicHomes.remove(homeName);
        if (ownerPublicHomes.isEmpty()) {
            publicHomesByOwner.remove(player.getUUID().toString());
        }

        saveHomes();
        player.sendSystemMessage(ModConfigs.translateWithFallback(
                "command.tpatool.home.privatized", "Home %s is no longer public.", homeName
        ));
        ModConfigs.DebugLog.info("Player {} set home {} as private.", player.getName().getString(), homeName);
        return 1;
    }

    private static int teleportToOtherHome(ServerPlayer player, String homeArg) {
        try {
            String[] parts = homeArg.split(":", 2);
            if (parts.length != 2) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_format", "Invalid format! Use playername:homename."
                ));
                return 0;
            }
            String ownerName = parts[0];
            String homeName = parts[1];

            Optional<GameProfile> profile = player.getServer().getProfileCache().get(ownerName);
            if (profile.isEmpty()) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }
            UUID ownerUUID = profile.get().getId();

            // Check if it's a public home
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(ownerUUID.toString());
            boolean isPublic = ownerPublicHomes != null && ownerPublicHomes.containsKey(homeName);

            // Check if it's a shared home
            Map<String, Home> homes = playerHomes.get(ownerUUID);
            if (homes == null || !homes.containsKey(homeName)) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }
            Home home = homes.get(homeName);

            if (!isPublic && !home.sharedPlayers.contains(player.getUUID())) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }

            ResourceKey<Level> dimensionKey = ResourceKey.create(Registries.DIMENSION, home.position.dimension);
            ServerLevel targetLevel = player.getServer().getLevel(dimensionKey);
            if (targetLevel == null) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_dimension", "Invalid dimension for home %s!", homeArg
                ));
                return 0;
            }

            recordLastPosition(player);
            player.teleportTo(
                    targetLevel,
                    home.position.x, home.position.y, home.position.z,
                    home.position.yRot, home.position.xRot
            );
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.other_teleported", "Teleported to %s's home %s.", ownerName, homeName
            ));
            ModConfigs.DebugLog.info("Player {} teleported to {}'s home {}", player.getName().getString(), ownerName, homeName);
            return 1;
        } catch (Exception e) {
            ModConfigs.DebugLog.error("Error executing /home otherhome {}: {}", homeArg, e.getMessage());
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }

    private static int listOtherHomes(ServerPlayer player) {
        try {
            if (publicHomesByOwner.isEmpty()) {
                player.sendSystemMessage(ModConfigs.translateWithFallback(
                        "command.tpatool.home.otherlist_empty", "No public or shared homes available."
                ));
                return 0;
            }
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.home.otherlist", "Public homes:"
            ));

            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUIDStr = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> homes = ownerEntry.getValue();

                UUID ownerUUID = UUID.fromString(ownerUUIDStr);
                String ownerName = player.getServer().getProfileCache().get(ownerUUID)
                        .map(GameProfile::getName).orElse("Unknown");

                for (java.util.Map.Entry<String, PublicHomeInfo> homeEntry : homes.entrySet()) {
                    String homeName = homeEntry.getKey();
                    PublicHomeInfo info = homeEntry.getValue();

                    Map<String, Home> ownerHomes = playerHomes.get(ownerUUID);
                    if (ownerHomes != null && ownerHomes.containsKey(homeName)) {
                        Home home = ownerHomes.get(homeName);
                        String dimensionName = home.position.dimension != null
                                ? home.position.dimension.toString()
                                : "unknown";
                        player.sendSystemMessage(Component.literal(String.format(
                                "- %s (%s): %s (x=%.2f, y=%.2f, z=%.2f)",
                                homeName, ownerName, dimensionName,
                                home.position.x, home.position.y, home.position.z
                        )));
                    }
                }
            }
            return 1;
        } catch (Exception e) {
            ModConfigs.DebugLog.error("Error executing /home otherlist: {}", e.getMessage());
            player.sendSystemMessage(ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }
}
