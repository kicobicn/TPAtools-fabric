package com.kicobicn.command;

import com.kicobicn.config.ModConfigs;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.PlayerChatMessage;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatHandler implements ServerMessageEvents.ChatMessage, ServerMessageEvents.AllowChatMessage {
    // Modify regex to match &number pattern (e.g., &1)
    private static final Pattern ITEM_PATTERN = Pattern.compile("&(\\d)");

    @Override
    public void onChatMessage(net.minecraft.network.chat.PlayerChatMessage message, ServerPlayer sender, net.minecraft.network.chat.ChatType.Bound bound) {
        try {
            String originalMessage = message.signedContent();

            ModConfigs.DebugLog.info("Processing chat message from {}: {}", sender.getName().getString(), originalMessage);

            // Process mention functionality
            Component processedMessage = Component.nullToEmpty(processMentions(originalMessage, sender));

            // Process item display functionality
            MutableComponent finalMessage = processItemDisplay(processedMessage, sender);

            // The message is handled by Fabric's system, so we just log the processed result
            ModConfigs.DebugLog.info("Chat message processed successfully");
        } catch (Exception e) {
            ModConfigs.DebugLog.error("Error processing chat message: {}", e.getMessage(), e);
        }
    }

    /**
     * Process mention functionality (returns Component for better color code handling)
     */
    private String processMentions(String message, ServerPlayer sender) {
        // Get all online players
        var onlinePlayers = sender.getServer().getPlayerList().getPlayers();
        String processedMessage = message; // Initialize to original message

        for (ServerPlayer target : onlinePlayers) {
            String playerName = target.getName().getString();

            // Skip self
            if (target.getUUID().equals(sender.getUUID())) {
                continue;
            }

            // If message contains player name (case insensitive)
            if (message.toLowerCase().contains(playerName.toLowerCase())) {
                ModConfigs.DebugLog.info("Player {} mentioned {}", sender.getName().getString(), playerName);

                // Color the player name
                processedMessage = processedMessage.replaceAll("(?i)" + Pattern.quote(playerName),
                        ChatFormatting.AQUA + playerName + ChatFormatting.RESET);

                // Use Title packet to implement centered title notification
                ClientboundSetTitleTextPacket titlePacket =
                        new ClientboundSetTitleTextPacket(
                                ModConfigs.translateWithFallback(
                                        "command.tpatool.chat.mention",
                                        "%s mentioned you",
                                        sender.getName()
                                ).withStyle(ChatFormatting.AQUA)
                        );
                // Set title display time, fade in/out time
                ClientboundSetTitlesAnimationPacket timesPacket =
                        new ClientboundSetTitlesAnimationPacket(10, 40, 10);
                target.connection.send(timesPacket);
                target.connection.send(titlePacket);

                                                                // Play sound effect
                // target.playNotifySound() method requires proper sound event handling
                // For now, skip playing sound to avoid compilation error
            }
        }

        // Special handling: if message contains sender's name, also set it to aqua
        String senderName = sender.getName().getString();
        if (processedMessage.contains(senderName)) {
            processedMessage = processedMessage.replaceAll("(?i)" + Pattern.quote(senderName),
                    ChatFormatting.AQUA + senderName + ChatFormatting.RESET);
        }

        return processedMessage;
    }

    /**
     * Process item display functionality
     */
    private MutableComponent processItemDisplay(Component originalComponent, ServerPlayer player) {
        String message = originalComponent.getString();
        List<Object> messageParts = new ArrayList<>();
        Matcher matcher = ITEM_PATTERN.matcher(message);
        int lastIndex = 0;

        while (matcher.find()) {
            // Add preceding plain text
            if (matcher.start() > lastIndex) {
                messageParts.add(message.substring(lastIndex, matcher.start()));
            }

            // Process item placeholder
            int slot = Integer.parseInt(matcher.group(1)) - 1; // Convert to 0-8 index
            if (slot >= 0 && slot <= 8) {
                var itemStack = player.getInventory().getItem(slot);
                if (!itemStack.isEmpty()) {
                    // Add item component
                    messageParts.add(createItemComponent(itemStack));
                    ModConfigs.DebugLog.info("Replaced &{} with item: {}", slot + 1, itemStack.getDisplayName().getString());
                } else {
                    // Slot is empty, keep original text
                    messageParts.add(matcher.group(0));
                    ModConfigs.DebugLog.info("Slot {} is empty, keeping original text", slot + 1);
                }
            } else {
                // Invalid slot, keep original text
                messageParts.add(matcher.group(0));
                ModConfigs.DebugLog.info("Invalid slot {}, keeping original text", slot + 1);
            }

            lastIndex = matcher.end();
        }

        // Add remaining text
        if (lastIndex < message.length()) {
            messageParts.add(message.substring(lastIndex));
        }

        // Build final message component
        MutableComponent finalMessage = Component.literal("");
        for (Object part : messageParts) {
            if (part instanceof String) {
                finalMessage.append(Component.literal((String) part));
            } else if (part instanceof MutableComponent) {
                finalMessage.append((MutableComponent) part);
            }
        }

        return finalMessage;
    }

    // Item display component
    private MutableComponent createItemComponent(net.minecraft.world.item.ItemStack itemStack) {
        // Get the item's original display name and color (keep its original style)
        MutableComponent itemDisplayName = itemStack.getDisplayName().copy();

        // Build component: outer brackets in gold, item name in its original color
        return Component.literal("[") // Left bracket, gold
                .withStyle(style -> style.withColor(ChatFormatting.GOLD))
                .append(itemDisplayName) // Item name, keep original color
                .append(Component.literal("]").withStyle(style -> style.withColor(ChatFormatting.GOLD)));
    }

    @Override
    public boolean allowChatMessage(PlayerChatMessage playerChatMessage, ServerPlayer serverPlayer, ChatType.Bound bound) {
        return true; // Allow chat messages to be processed
    }
}