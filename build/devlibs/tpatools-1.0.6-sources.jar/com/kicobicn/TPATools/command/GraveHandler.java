package com.kicobicn.TPATools.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kicobicn.TPATools.config.ModConfigs;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GraveHandler {
    private static final Map<UUID, BackHandler.PlayerPosition> gravePositions = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // Load death positions
    public static void loadGraves() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_graves.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Object> loadedGraves = GSON.fromJson(jsonContent, java.util.Map.class);
                gravePositions.clear();
                if (loadedGraves != null) {
                    loadedGraves.forEach((uuidStr, pos) -> {
                        UUID uuid = UUID.fromString(uuidStr);
                        // 将Map对象转换为BackHandler.PlayerPosition对象
                        if (pos instanceof java.util.Map) {
                            java.util.Map<String, Object> posMap = (java.util.Map<String, Object>) pos;
                            String dimensionStr = (String) posMap.get("dimension");
                            double x = (Double) posMap.get("x");
                            double y = (Double) posMap.get("y");
                            double z = (Double) posMap.get("z");
                            float yRot = ((Double) posMap.get("yRot")).floatValue();
                            float xRot = ((Double) posMap.get("xRot")).floatValue();
                            
                            BackHandler.PlayerPosition position = new BackHandler.PlayerPosition(
                                x, y, z, yRot, xRot, new ResourceLocation(dimensionStr)
                            );
                            
                            gravePositions.put(uuid, position);
                        }
                    });
                    com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Loaded graves from tpatool_graves.json");
                }
            }
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to load graves: {}", e.getMessage());
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error parsing grave data: {}", e.getMessage());
        }
    }

    // Save death positions
    public static void saveGraves() {
        try {
            Path path = com.kicobicn.TPATools.config.ModConfigs.getConfigDir().resolve("tpatool_graves.json");
            Files.writeString(path, GSON.toJson(gravePositions));
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Saved graves to tpatool_graves.json");
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to save graves: {}", e.getMessage());
        }
    }

    // Register commands
    public static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher, CommandBuildContext registryAccess, Commands.CommandSelection environment) {
        dispatcher.register(
                Commands.literal("grave")
                        .requires(source -> com.kicobicn.TPATools.config.ModConfigs.checkCommandPermission(source, "grave"))
                        .executes(context -> {
                            try {
                                ServerPlayer player = context.getSource().getPlayerOrException();
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Executing /grave command for player: {}", player.getName().getString());
                                return teleportToGrave(player);
                            } catch (Exception e) {
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Unexpected error in /grave command: ", e);
                                context.getSource().sendFailure(Component.literal("An unexpected error occurred."));
                                return 0;
                            }
                        })
        );
    }

    public static void onPlayerDeath(ServerPlayer player) {
        gravePositions.put(player.getUUID(), new BackHandler.PlayerPosition(
                player.serverLevel(),
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot()
        ));
        saveGraves();
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Recorded grave for {} at dimension={}, x={}, y={}, z={}",
                player.getName().getString(), player.serverLevel().dimension().location(),
                player.getX(), player.getY(), player.getZ());
    }

    // Teleport command
    private static int teleportToGrave(ServerPlayer player) {
        BackHandler.PlayerPosition pos = gravePositions.get(player.getUUID());
        if (pos == null) {
            player.sendSystemMessage(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.grave.no_position", "No previous death position recorded!"
            ));
            return 0;
        }
        ServerLevel level = player.getServer().getLevel(ResourceKey.create(Registries.DIMENSION, pos.dimension));
        if (level == null) {
            player.sendSystemMessage(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.grave.invalid_dimension", "Invalid dimension for death position!"
            ));
            gravePositions.remove(player.getUUID());
            saveGraves();
            return 0;
        }
        BackHandler.PlayerPosition currentPosition = new BackHandler.PlayerPosition(
                player.serverLevel(),
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot()
        );
        player.teleportTo(level, pos.x, pos.y, pos.z, pos.yRot, pos.xRot);
        BackHandler.previousPositions.put(player.getUUID(), currentPosition);
        player.sendSystemMessage(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.grave.success", "Teleported to last death position."
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} teleported to grave at dimension={}, x={}, y={}, z={}",
                player.getName().getString(), pos.dimension, pos.x, pos.y, pos.z);
        return 1;
    }
}
