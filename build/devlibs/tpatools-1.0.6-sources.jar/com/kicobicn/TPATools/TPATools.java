package com.kicobicn.TPATools;

import com.kicobicn.TPATools.chat.ChatHandler;
import com.kicobicn.TPATools.command.BackHandler;
import com.kicobicn.TPATools.command.GraveHandler;
import com.kicobicn.TPATools.command.HomeHandler;
import com.kicobicn.TPATools.command.TPAHandler;
import com.kicobicn.TPATools.config.ModConfigs;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TPATools implements ModInitializer {
	public static final String MODID = "tpatools";
	public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

	@Override
	public void onInitialize() {
		LOGGER.info("TPATools mod is initializing...");

		ChatHandler.register();

		// Register commands
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			TPAHandler.registerCommands(dispatcher, registryAccess, environment);
			HomeHandler.registerCommands(dispatcher, registryAccess, environment);
			GraveHandler.registerCommands(dispatcher, registryAccess, environment);
			BackHandler.registerCommands(dispatcher, registryAccess, environment);
			ModConfigs.registerCommands(dispatcher, registryAccess, environment);
		});

		// Register server lifecycle events
		ServerLifecycleEvents.SERVER_STARTING.register(this::onServerStarting);
		ServerLifecycleEvents.SERVER_STOPPING.register(this::onServerStopping);

		// Register server tick event
		ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);

		// Register player death event
		ServerPlayerEvents.ALLOW_DEATH.register(this::onPlayerDeath);

		// Initialize configs
		ModConfigs.initializeConfig(FabricLoader.getInstance().getConfigDir());
	}

	private void onServerStarting(MinecraftServer server) {
		TPAHandler.onServerStarting(server);
		HomeHandler.loadHomes();
		GraveHandler.loadGraves();
		TPAHandler.loadToggleStates();
		TPAHandler.loadLockedPlayers();
		TPAHandler.loadCommandPermissions();
	}

	private void onServerStopping(MinecraftServer server) {
		HomeHandler.saveHomes();
		GraveHandler.saveGraves();
		TPAHandler.saveToggleStates();
		TPAHandler.saveLockedPlayers();
		TPAHandler.saveCommandPermissions();
	}

	private void onServerTick(MinecraftServer server) {
		TPAHandler.tick();
	}

	private boolean onPlayerDeath(ServerPlayer player, net.minecraft.world.damagesource.DamageSource damageSource, float damageAmount) {
		GraveHandler.onPlayerDeath(player);
		return true; // Allow the death to proceed
	}
}