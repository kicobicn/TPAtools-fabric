package com.kicobicn.TPATools.command;

import com.kicobicn.TPATools.config.ModConfigs;
import com.mojang.brigadier.CommandDispatcher;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

public class BackHandler {
    public static final Map<UUID, PlayerPosition> previousPositions = new HashMap<>();

    public static class PlayerPosition {
        public final class_2960 dimension;
        public final double x, y, z;
        public final float yRot, xRot;

        public PlayerPosition(class_3218 level, double x, double y, double z, float yRot, float xRot) {
            this.dimension = level.method_27983().method_29177();
            this.x = x;
            this.y = y;
            this.z = z;
            this.yRot = yRot;
            this.xRot = xRot;
        }
        
        // 添加一个可以从JSON反序列化使用的构造函数
        public PlayerPosition(double x, double y, double z, float yRot, float xRot, class_2960 dimension) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yRot = yRot;
            this.xRot = xRot;
            this.dimension = dimension;
        }
    }

    public static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
                class_2170.method_9247("back")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "back"))
                        .executes(context -> {
                            try {
                                class_3222 player = context.getSource().method_9207();
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Executing /back command for player: {}", player.method_5477().getString());
                                return teleportBack(player);
                            } catch (Exception e) {
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Unexpected error in /back command: ", e);
                                context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                return 0;
                            }
                        })
        );
    }

    public static void recordPosition(class_3222 player) {
        previousPositions.put(player.method_5667(), new PlayerPosition(
                player.method_51469(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.log("Recorded position for {}: dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), player.method_51469().method_27983().method_29177(),
                player.method_23317(), player.method_23318(), player.method_23321());
    }

    private static int teleportBack(class_3222 player) {
        PlayerPosition pos = previousPositions.get(player.method_5667());
        if (pos == null) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.back.no_position", "No previous position recorded!"
            ));
            return 0;
        }
        class_3218 level = player.method_5682().method_3847(class_5321.method_29179(class_7924.field_41223, pos.dimension));
        if (level == null) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.back.invalid_dimension", "Invalid dimension for previous position!"
            ));
            previousPositions.remove(player.method_5667());
            return 0;
        }
        PlayerPosition currentPosition = new PlayerPosition(
                player.method_51469(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()
        );
        player.method_14251(level, pos.x, pos.y, pos.z, pos.yRot, pos.xRot);
        previousPositions.put(player.method_5667(), currentPosition);
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.back.success", "Teleported to previous position."
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} teleported back to dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), pos.dimension, pos.x, pos.y, pos.z);
        return 1;
    }
}
