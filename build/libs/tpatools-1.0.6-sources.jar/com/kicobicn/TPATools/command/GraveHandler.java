package com.kicobicn.TPATools.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kicobicn.TPATools.config.ModConfigs;
import com.mojang.brigadier.CommandDispatcher;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

public class GraveHandler {
    private static final Map<UUID, BackHandler.PlayerPosition> gravePositions = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // Load death positions
    public static void loadGraves() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_graves.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Object> loadedGraves = GSON.fromJson(jsonContent, java.util.Map.class);
                gravePositions.clear();
                if (loadedGraves != null) {
                    loadedGraves.forEach((uuidStr, pos) -> {
                        UUID uuid = UUID.fromString(uuidStr);
                        // 将Map对象转换为BackHandler.PlayerPosition对象
                        if (pos instanceof java.util.Map) {
                            java.util.Map<String, Object> posMap = (java.util.Map<String, Object>) pos;
                            String dimensionStr = (String) posMap.get("dimension");
                            double x = (Double) posMap.get("x");
                            double y = (Double) posMap.get("y");
                            double z = (Double) posMap.get("z");
                            float yRot = ((Double) posMap.get("yRot")).floatValue();
                            float xRot = ((Double) posMap.get("xRot")).floatValue();
                            
                            BackHandler.PlayerPosition position = new BackHandler.PlayerPosition(
                                x, y, z, yRot, xRot, new class_2960(dimensionStr)
                            );
                            
                            gravePositions.put(uuid, position);
                        }
                    });
                    com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Loaded graves from tpatool_graves.json");
                }
            }
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to load graves: {}", e.getMessage());
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error parsing grave data: {}", e.getMessage());
        }
    }

    // Save death positions
    public static void saveGraves() {
        try {
            Path path = com.kicobicn.TPATools.config.ModConfigs.getConfigDir().resolve("tpatool_graves.json");
            Files.writeString(path, GSON.toJson(gravePositions));
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Saved graves to tpatool_graves.json");
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to save graves: {}", e.getMessage());
        }
    }

    // Register commands
    public static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
                class_2170.method_9247("grave")
                        .requires(source -> com.kicobicn.TPATools.config.ModConfigs.checkCommandPermission(source, "grave"))
                        .executes(context -> {
                            try {
                                class_3222 player = context.getSource().method_9207();
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Executing /grave command for player: {}", player.method_5477().getString());
                                return teleportToGrave(player);
                            } catch (Exception e) {
                                com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Unexpected error in /grave command: ", e);
                                context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                return 0;
                            }
                        })
        );
    }

    public static void onPlayerDeath(class_3222 player) {
        gravePositions.put(player.method_5667(), new BackHandler.PlayerPosition(
                player.method_51469(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()
        ));
        saveGraves();
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Recorded grave for {} at dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), player.method_51469().method_27983().method_29177(),
                player.method_23317(), player.method_23318(), player.method_23321());
    }

    // Teleport command
    private static int teleportToGrave(class_3222 player) {
        BackHandler.PlayerPosition pos = gravePositions.get(player.method_5667());
        if (pos == null) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.grave.no_position", "No previous death position recorded!"
            ));
            return 0;
        }
        class_3218 level = player.method_5682().method_3847(class_5321.method_29179(class_7924.field_41223, pos.dimension));
        if (level == null) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.grave.invalid_dimension", "Invalid dimension for death position!"
            ));
            gravePositions.remove(player.method_5667());
            saveGraves();
            return 0;
        }
        BackHandler.PlayerPosition currentPosition = new BackHandler.PlayerPosition(
                player.method_51469(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()
        );
        player.method_14251(level, pos.x, pos.y, pos.z, pos.yRot, pos.xRot);
        BackHandler.previousPositions.put(player.method_5667(), currentPosition);
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.grave.success", "Teleported to last death position."
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} teleported to grave at dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), pos.dimension, pos.x, pos.y, pos.z);
        return 1;
    }
}
