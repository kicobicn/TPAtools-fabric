package com.kicobicn.TPATools.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kicobicn.TPATools.config.ModConfigs;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;

public class HomeHandler {
    private static final Map<UUID, Map<String, Home>> playerHomes = new HashMap<>();
    private static final Map<String, Map<String, PublicHomeInfo>> publicHomesByOwner = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // PublicHomeInfo class to store public home UUID and username
    private static class PublicHomeInfo {
        public UUID ownerUUID;
        public String ownerName;
        public String homeName;

        public PublicHomeInfo(UUID ownerUUID, String ownerName, String homeName) {
            this.ownerUUID = ownerUUID;
            this.ownerName = ownerName;
            this.homeName = homeName;
        }
    }

    // Store last position mapping
    private static final Map<UUID, Home.Position> lastPositions = new HashMap<>();

    public static class Home {
        public static class Position {
            public double x, y, z;
            public float xRot, yRot;
            public class_2960 dimension;

            public Position(double x, double y, double z, float xRot, float yRot, class_2960 dimension) {
                this.x = x; this.y = y; this.z = z;
                this.xRot = xRot; this.yRot = yRot; this.dimension = dimension;
            }
        }

        public Position position;
        public List<UUID> sharedPlayers;

        public Home(Position position, List<UUID> sharedPlayers) {
            this.position = position;
            this.sharedPlayers = sharedPlayers != null ? sharedPlayers : new ArrayList<>();
        }
    }

    private static void recordLastPosition(class_3222 player) {
        class_2960 dimension = player.method_37908().method_27983().method_29177();
        lastPositions.put(player.method_5667(), new Home.Position(
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36455(), player.method_36454(), dimension
        ));
    }

    public static void loadHomes() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_homes.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Object> data = GSON.fromJson(jsonContent, java.util.Map.class);
                playerHomes.clear();
                publicHomesByOwner.clear();

                if (data != null) {
                    // Load playerHomes
                    if (data.containsKey("playerHomes")) {
                        java.util.Map<String, Object> homesData = (java.util.Map<String, Object>) data.get("playerHomes");
                        if (homesData != null) {
                            for (java.util.Map.Entry<String, Object> entry : homesData.entrySet()) {
                                UUID playerUUID = UUID.fromString(entry.getKey());
                                java.util.Map<String, Object> playerHomesData = (java.util.Map<String, Object>) entry.getValue();
                                
                                Map<String, Home> playerHomeMap = new HashMap<>();
                                for (java.util.Map.Entry<String, Object> homeEntry : playerHomesData.entrySet()) {
                                    String homeName = homeEntry.getKey();
                                    java.util.Map<String, Object> homeData = (java.util.Map<String, Object>) homeEntry.getValue();
                                    
                                    // Process position
                                    java.util.Map<String, Object> positionData = (java.util.Map<String, Object>) homeData.get("position");
                                    if (positionData != null) {
                                        double x = ((Double) positionData.get("x")).doubleValue();
                                        double y = ((Double) positionData.get("y")).doubleValue();
                                        double z = ((Double) positionData.get("z")).doubleValue();
                                        float xRot = ((Double) positionData.get("xRot")).floatValue();
                                        float yRot = ((Double) positionData.get("yRot")).floatValue();
                                        String dimensionStr = (String) positionData.get("dimension");
                                        
                                        Home.Position pos = new Home.Position(x, y, z, xRot, yRot, new class_2960(dimensionStr));
                                        
                                        // Process sharedPlayers
                                        List<UUID> sharedPlayers = new ArrayList<>();
                                        java.util.List<Object> sharedPlayersData = (java.util.List<Object>) homeData.get("sharedPlayers");
                                        if (sharedPlayersData != null) {
                                            for (Object obj : sharedPlayersData) {
                                                sharedPlayers.add(UUID.fromString(obj.toString()));
                                            }
                                        }
                                        
                                        playerHomeMap.put(homeName, new Home(pos, sharedPlayers));
                                    }
                                }
                                playerHomes.put(playerUUID, playerHomeMap);
                            }
                        }
                    }

                    // Load publicHomesByOwner
                    if (data.containsKey("publicHomesByOwner")) {
                        java.util.Map<String, Object> publicHomesData = (java.util.Map<String, Object>) data.get("publicHomesByOwner");
                        if (publicHomesData != null) {
                            for (java.util.Map.Entry<String, Object> entry : publicHomesData.entrySet()) {
                                String ownerUUID = entry.getKey();
                                java.util.Map<String, Object> ownerHomesData = (java.util.Map<String, Object>) entry.getValue();
                                
                                Map<String, PublicHomeInfo> ownerHomesMap = new HashMap<>();
                                for (java.util.Map.Entry<String, Object> homeEntry : ownerHomesData.entrySet()) {
                                    String homeName = homeEntry.getKey();
                                    java.util.Map<String, Object> homeInfoData = (java.util.Map<String, Object>) homeEntry.getValue();
                                    
                                    String ownerUUIDStr = (String) homeInfoData.get("ownerUUID");
                                    String ownerName = (String) homeInfoData.get("ownerName");
                                    
                                    ownerHomesMap.put(homeName, new PublicHomeInfo(
                                            UUID.fromString(ownerUUIDStr),
                                            ownerName,
                                            homeName
                                    ));
                                }
                                publicHomesByOwner.put(ownerUUID, ownerHomesMap);
                            }
                        }
                    }

                    com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Loaded homes and public homes from {}", path.toString());
                }
            }
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to load homes: {}", e.getMessage());
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error parsing home data: {}", e.getMessage());
        }
    }

    public static void saveHomes() {
        try {
            Path path = com.kicobicn.TPATools.config.ModConfigs.getConfigDir().resolve("tpatool_homes.json");

            // Create a serializable map for player homes
            java.util.Map<String, Object> playerHomesData = new java.util.HashMap<>();
            for (Map.Entry<UUID, Map<String, Home>> playerEntry : playerHomes.entrySet()) {
                String playerUUID = playerEntry.getKey().toString();
                Map<String, Home> playerHomeMap = playerEntry.getValue();
                
                java.util.Map<String, Object> homeData = new java.util.HashMap<>();
                for (Map.Entry<String, Home> homeEntry : playerHomeMap.entrySet()) {
                    String homeName = homeEntry.getKey();
                    Home home = homeEntry.getValue();
                    
                    // Create a map representation of the home that can be serialized
                    java.util.Map<String, Object> serializedHome = new java.util.HashMap<>();
                    java.util.Map<String, Object> positionData = new java.util.HashMap<>();
                    positionData.put("x", home.position.x);
                    positionData.put("y", home.position.y);
                    positionData.put("z", home.position.z);
                    positionData.put("xRot", (double) home.position.xRot);
                    positionData.put("yRot", (double) home.position.yRot);
                    positionData.put("dimension", home.position.dimension.toString()); // Convert ResourceLocation to string
                    
                    serializedHome.put("position", positionData);
                    serializedHome.put("sharedPlayers", home.sharedPlayers);
                    
                    homeData.put(homeName, serializedHome);
                }
                playerHomesData.put(playerUUID, homeData);
            }

            java.util.Map<String, Object> data = new java.util.HashMap<>();
            data.put("playerHomes", playerHomesData);

            // Public homes save format
            java.util.Map<String, Object> publicHomesData = new java.util.HashMap<>();
            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUID = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> homes = ownerEntry.getValue();
                publicHomesData.put(ownerUUID, homes);
            }
            data.put("publicHomesByOwner", publicHomesData);

            Files.writeString(path, GSON.toJson(data));
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Saved homes and public homes to {}", path.toString());
        } catch (IOException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to save homes: {}", e.getMessage());
        }
    }

    // Tab completion: player's own homes
    private static final SuggestionProvider<class_2168> OWN_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();
            Map<String, Home> homes = playerHomes.get(player.method_5667());
            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: public homes
    private static final SuggestionProvider<class_2168> PUBLIC_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());

            if (ownerPublicHomes != null) {
                for (String homeName : ownerPublicHomes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: non-public homes
    private static final SuggestionProvider<class_2168> NON_PUBLIC_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();
            Map<String, Home> homes = playerHomes.get(player.method_5667());
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());

            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    // Check if home is not public
                    if (ownerPublicHomes == null || !ownerPublicHomes.containsKey(homeName)) {
                        builder.suggest(homeName);
                    }
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: accessible homes (own)
    private static final SuggestionProvider<class_2168> ACCESSIBLE_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();
            Map<String, Home> homes = playerHomes.get(player.method_5667());
            if (homes != null) {
                for (String homeName : homes.keySet()) {
                    builder.suggest(homeName);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to provide suggestions for /home tp: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: /home otherhome playername:homename
    private static final SuggestionProvider<class_2168> OTHER_HOME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();

            // Handle public homes
            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUIDStr = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> ownerHomes = ownerEntry.getValue();

                UUID ownerUUID = UUID.fromString(ownerUUIDStr);
                String ownerName = player.method_5682().method_3793().method_14512(ownerUUID)
                        .map(GameProfile::getName).orElse("Unknown");

                for (String homeName : ownerHomes.keySet()) {
                    builder.suggest(ownerName + ":" + homeName);
                }
            }

            // Handle private shared homes
            for (java.util.Map.Entry<UUID, Map<String, Home>> entry : playerHomes.entrySet()) {
                UUID ownerUUID = entry.getKey();
                if (!ownerUUID.equals(player.method_5667())) {
                    String ownerName = player.method_5682().method_3793().method_14512(ownerUUID)
                            .map(GameProfile::getName).orElse("Unknown");
                    for (java.util.Map.Entry<String, Home> homeEntry : entry.getValue().entrySet()) {
                        if (homeEntry.getValue().sharedPlayers.contains(player.method_5667())) {
                            builder.suggest(ownerName + ":" + homeEntry.getKey());
                        }
                    }
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to provide suggestions for /home otherhome: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    // Tab completion: /home sharelist in/out parameter
    private static final SuggestionProvider<class_2168> SHARELIST_SUGGESTIONS = (context, builder) -> {
        builder.suggest("in");
        builder.suggest("out");
        return CompletableFuture.completedFuture(builder.build());
    };

    // Tab completion: player names for /home unshare (support offline players)
    private static final SuggestionProvider<class_2168> PLAYER_NAME_SUGGESTIONS = (context, builder) -> {
        try {
            class_3222 player = context.getSource().method_9207();
            MinecraftServer server = player.method_5682();
            if (server != null) {
                // Get all UUIDs from playerHomes and convert to player names
                for (UUID uuid : playerHomes.keySet()) {
                    server.method_3793().method_14512(uuid)
                            .map(GameProfile::getName)
                            .ifPresent(builder::suggest);
                }
            }
            return CompletableFuture.completedFuture(builder.build());
        } catch (CommandSyntaxException e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Failed to provide player name suggestions: {}", e.getMessage());
            return CompletableFuture.completedFuture(builder.build());
        }
    };

    public static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        dispatcher.register(
                class_2170.method_9247("home")
                        .requires(source -> com.kicobicn.TPATools.config.ModConfigs.checkCommandPermission(source, "home"))
                        .then(class_2170.method_9247("tp")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(ACCESSIBLE_HOME_SUGGESTIONS)
                                        .executes(context -> teleportToHome(context.getSource().method_9207(), StringArgumentType.getString(context, "name")))))
                        .then(class_2170.method_9247("set")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .executes(context -> setHome(context.getSource().method_9207(), StringArgumentType.getString(context, "name")))))
                        .then(class_2170.method_9247("list")
                                .executes(context -> listHomes(context.getSource().method_9207())))
                        .then(class_2170.method_9247("remove")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .executes(context -> removeHome(context.getSource().method_9207(), StringArgumentType.getString(context, "name")))))
                        .then(class_2170.method_9247("rename")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .then(RequiredArgumentBuilder.<class_2168, String>argument("newName", StringArgumentType.string())
                                                .executes(context -> renameHome(
                                                        context.getSource().method_9207(),
                                                        StringArgumentType.getString(context, "name"),
                                                        StringArgumentType.getString(context, "newName")
                                                )))))
                        .then(class_2170.method_9247("share")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                                                                                                                                                                                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                                .executes(context -> shareHome(
                                                        context.getSource().method_9207(),
                                                        StringArgumentType.getString(context, "name"),
                                                        class_2186.method_9315(context, "player")
                                                )))))
                        .then(class_2170.method_9247("public")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(NON_PUBLIC_HOME_SUGGESTIONS)
                                        .executes(context -> setPublicHome(context.getSource().method_9207(), StringArgumentType.getString(context, "name")))))
                        .then(class_2170.method_9247("private")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(PUBLIC_HOME_SUGGESTIONS)
                                        .executes(context -> setPrivateHome(context.getSource().method_9207(), StringArgumentType.getString(context, "name")))))
                        .then(class_2170.method_9247("otherhome")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("home", StringArgumentType.greedyString())
                                        .suggests(OTHER_HOME_SUGGESTIONS)
                                        .executes(context -> teleportToOtherHome(context.getSource().method_9207(), StringArgumentType.getString(context, "home")))))
                        .then(class_2170.method_9247("otherlist")
                                .executes(context -> listOtherHomes(context.getSource().method_9207())))
                        .then(class_2170.method_9247("sharelist")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("type", StringArgumentType.string())
                                        .suggests(SHARELIST_SUGGESTIONS)
                                        .executes(context -> shareList(
                                                context.getSource().method_9207(),
                                                StringArgumentType.getString(context, "type")
                                        ))))
                        .then(class_2170.method_9247("unshare")
                                .then(RequiredArgumentBuilder.<class_2168, String>argument("name", StringArgumentType.string())
                                        .suggests(OWN_HOME_SUGGESTIONS)
                                        .executes(context -> unshareHome(
                                                context.getSource().method_9207(),
                                                StringArgumentType.getString(context, "name"),
                                                null,
                                                null
                                        ))
                                        .then(RequiredArgumentBuilder.<class_2168, String>argument("player", StringArgumentType.string())
                                                .suggests(PLAYER_NAME_SUGGESTIONS)
                                                .executes(context -> unshareHome(
                                                        context.getSource().method_9207(),
                                                        StringArgumentType.getString(context, "name"),
                                                        StringArgumentType.getString(context, "player"),
                                                        context.getSource()
                                                )))))
        );
    }

    private static int setHome(class_3222 player, String homeName) {
        Map<String, Home> homes = playerHomes.computeIfAbsent(player.method_5667(), k -> new HashMap<>());
        if (homes.size() >= com.kicobicn.TPATools.config.ModConfigs.MAX_HOMES) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.limit_exceeded", "You have reached the maximum number of homes (%s)!", com.kicobicn.TPATools.config.ModConfigs.MAX_HOMES
            ));
            return 0;
        }
        if (homes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.name_exists", "A home named %s already exists!", homeName
            ));
            return 0;
        }
        class_2960 dimension = player.method_37908().method_27983().method_29177();
        Home.Position position = new Home.Position(
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36455(), player.method_36454(), dimension
        );
        homes.put(homeName, new Home(position, new ArrayList<>()));
        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.set", "Home %s set at your current position.", homeName
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} set home {} at {}", player.method_5477().getString(), homeName, dimension);
        return 1;
    }

    private static int teleportToHome(class_3222 player, String name) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes != null && homes.containsKey(name)) {
            Home home = homes.get(name);
            class_3218 level = player.method_5682().method_3847(class_5321.method_29179(class_7924.field_41223, home.position.dimension));
            if (level == null) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_dimension", "Invalid dimension for home %s!", name
                ));
                return 0;
            }
            BackHandler.recordPosition(player);
            player.method_14251(level, home.position.x, home.position.y, home.position.z,
                    home.position.yRot, home.position.xRot);
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.teleported", "Teleported to home %s.", name
            ));
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} teleported to home {} at dimension={}, x={}, y={}, z={}",
                    player.method_5477().getString(), name, home.position.dimension,
                    home.position.x, home.position.y, home.position.z);
            return 1;
        }
        return teleportToOtherHome(player, name); // Try to handle as other's home
    }

    private static int listHomes(class_3222 player) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || homes.isEmpty()) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.list_empty", "You have no homes set."
            ));
            return 0;
        }
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.list", "Your homes:"
        ));
        for (java.util.Map.Entry<String, Home> entry : homes.entrySet()) {
            Home home = entry.getValue();
            player.method_43496(class_2561.method_43470(String.format(
                    "- %s: %s (x=%.2f, y=%.2f, z=%.2f)",
                    entry.getKey(), home.position.dimension, home.position.x, home.position.y, home.position.z
            )));
        }
        return 1;
    }

    private static int shareList(class_3222 player, String type) {
        try {
            if (!type.equals("in") && !type.equals("out")) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.invalid_type", "Invalid type! Use 'in' or 'out'."
                ));
                return 0;
            }
            if (type.equals("in")) {
                boolean found = false;
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.in", "Homes shared with you:"
                ));
                for (java.util.Map.Entry<UUID, Map<String, Home>> entry : playerHomes.entrySet()) {
                    UUID ownerUUID = entry.getKey();
                    String ownerName = player.method_5682().method_3793().method_14512(ownerUUID)
                            .map(GameProfile::getName).orElse("Unknown");
                    for (java.util.Map.Entry<String, Home> homeEntry : entry.getValue().entrySet()) {
                        String homeName = homeEntry.getKey();
                        Home home = homeEntry.getValue();
                        if (home.sharedPlayers.contains(player.method_5667())) {
                            String dimensionName = home.position.dimension != null
                                    ? home.position.dimension.toString()
                                    : "unknown";
                            player.method_43496(class_2561.method_43470(String.format(
                                    "- %s (%s): %s (x=%.2f, y=%.2f, z=%.2f)",
                                    homeName, ownerName, dimensionName,
                                    home.position.x, home.position.y, home.position.z
                            )));
                            found = true;
                        }
                    }
                }
                if (!found) {
                    player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.in_empty", "No homes are shared with you."
                    ));
                    return 0;
                }
                return 1;
            } else {
                Map<String, Home> homes = playerHomes.get(player.method_5667());
                if (homes == null || homes.isEmpty()) {
                    player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.out_empty", "You have not shared any homes."
                    ));
                    return 0;
                }
                boolean found = false;
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.sharelist.out", "Homes you have shared:"
                ));
                for (java.util.Map.Entry<String, Home> homeEntry : homes.entrySet()) {
                    String homeName = homeEntry.getKey();
                    Home home = homeEntry.getValue();
                    if (!home.sharedPlayers.isEmpty()) {
                        List<String> sharedPlayerNames = new ArrayList<>();
                        for (UUID sharedUUID : home.sharedPlayers) {
                            String playerName = player.method_5682().method_3793().method_14512(sharedUUID)
                                    .map(GameProfile::getName).orElse("Unknown");
                            sharedPlayerNames.add(playerName);
                        }
                        String dimensionName = home.position.dimension != null
                                ? home.position.dimension.toString()
                                : "unknown";
                        player.method_43496(class_2561.method_43470(String.format(
                                "- %s: Shared with %s (%s, x=%.2f, y=%.2f, z=%.2f)",
                                homeName, String.join(", ", sharedPlayerNames),
                                dimensionName, home.position.x, home.position.y, home.position.z
                        )));
                        found = true;
                    }
                }
                if (!found) {
                    player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                            "command.tpatool.sharelist.out_empty", "You have not shared any homes."
                    ));
                    return 0;
                }
                return 1;
            }
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error executing /home sharelist {}: {}", type, e.getMessage());
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }

    private static int removeHome(class_3222 player, String name) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(name)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", name
            ));
            return 0;
        }

        homes.remove(name);

        // Also remove from public homes list
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());
        if (ownerPublicHomes != null) {
            ownerPublicHomes.remove(name);
            if (ownerPublicHomes.isEmpty()) {
                publicHomesByOwner.remove(player.method_5667().toString());
            }
        }

        if (homes.isEmpty()) {
            playerHomes.remove(player.method_5667());
        }

        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.removed", "Home %s removed.", name
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} removed home {}", player.method_5477().getString(), name);
        return 1;
    }

    private static int renameHome(class_3222 player, String oldName, String newName) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(oldName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", oldName
            ));
            return 0;
        }
        if (homes.containsKey(newName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.name_exists", "A home named %s already exists!", newName
            ));
            return 0;
        }

        Home home = homes.remove(oldName);
        homes.put(newName, home);

        // Update name in public homes list if this home is public
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());
        if (ownerPublicHomes != null && ownerPublicHomes.containsKey(oldName)) {
            PublicHomeInfo info = ownerPublicHomes.remove(oldName);
            ownerPublicHomes.put(newName, new PublicHomeInfo(info.ownerUUID, info.ownerName, newName));
        }

        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.renamed", "Home %s renamed to %s.", oldName, newName
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} renamed home {} to {}", player.method_5477().getString(), oldName, newName);
        return 1;
    }

    private static int shareHome(class_3222 player, String name, class_3222 target) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(name)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", name
            ));
            return 0;
        }
        Home home = homes.get(name);
        if (home.sharedPlayers.contains(target.method_5667())) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.already_shared", "Home %s is already shared with %s!", name, target.method_5477()
            ));
            return 0;
        }
        home.sharedPlayers.add(target.method_5667());
        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.shared", "Home %s shared with %s.", name, target.method_5477()
        ));
        target.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.shared_received", "%s shared their home %s with you.", player.method_5477(), name
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} shared home {} with {}", player.method_5477().getString(), name, target.method_5477().getString());
        return 1;
    }

    // unshareHome method
    private static int unshareHome(class_3222 player, String homeName, String targetPlayerName, class_2168 source) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }
        Home home = homes.get(homeName);
        if (targetPlayerName == null) {
            if (home.sharedPlayers.isEmpty()) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.no_players", "Home %s is not shared with anyone!", homeName
                ));
                return 0;
            }
            home.sharedPlayers.clear();
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.unshare.all", "Removed sharing of home %s for all players.", homeName
            ));
            saveHomes();
            return 1;
        } else {
            MinecraftServer server = player.method_5682();
            Optional<GameProfile> profile = server.method_3793().method_14515(targetPlayerName);
            if (profile.isEmpty()) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.player_not_found", "Player %s not found!", targetPlayerName
                ));
                return 0;
            }
            UUID targetUUID = profile.get().getId();
            if (!home.sharedPlayers.contains(targetUUID)) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.not_shared", "Home %s is not shared with %s!", homeName, targetPlayerName
                ));
                return 0;
            }
            home.sharedPlayers.remove(targetUUID);
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.unshare.player", "Removed sharing of home %s with %s.", homeName, targetPlayerName
            ));
            class_3222 targetPlayer = server.method_3760().method_14602(targetUUID);
            if (targetPlayer != null) {
                targetPlayer.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.unshare.notify", "%s has removed sharing of their home %s with you.", player.method_5477().getString(), homeName
                ));
            }
            saveHomes();
            return 1;
        }
    }

    private static int setPublicHome(class_3222 player, String homeName) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }

        // Check if already public
        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());
        if (ownerPublicHomes != null && ownerPublicHomes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.already_public", "Home %s is already public!", homeName
            ));
            return 0;
        }

        // Add public home info
        String ownerName = player.method_5477().getString();
        PublicHomeInfo info = new PublicHomeInfo(player.method_5667(), ownerName, homeName);

        // Use player UUID as outer key, home name as inner key
        publicHomesByOwner.computeIfAbsent(player.method_5667().toString(), k -> new java.util.HashMap<>())
                .put(homeName, info);

        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.publicized", "Home %s is now public.", homeName
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} set home {} as public.", player.method_5477().getString(), homeName);
        return 1;
    }

    private static int setPrivateHome(class_3222 player, String homeName) {
        Map<String, Home> homes = playerHomes.get(player.method_5667());
        if (homes == null || !homes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_found", "Home %s not found!", homeName
            ));
            return 0;
        }

        java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(player.method_5667().toString());
        if (ownerPublicHomes == null || !ownerPublicHomes.containsKey(homeName)) {
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.not_public", "Home %s is not public!", homeName
            ));
            return 0;
        }

        // Remove public home info
        ownerPublicHomes.remove(homeName);
        if (ownerPublicHomes.isEmpty()) {
            publicHomesByOwner.remove(player.method_5667().toString());
        }

        saveHomes();
        player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                "command.tpatool.home.privatized", "Home %s is no longer public.", homeName
        ));
        com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} set home {} as private.", player.method_5477().getString(), homeName);
        return 1;
    }

    private static int teleportToOtherHome(class_3222 player, String homeArg) {
        try {
            String[] parts = homeArg.split(":", 2);
            if (parts.length != 2) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_format", "Invalid format! Use playername:homename."
                ));
                return 0;
            }
            String ownerName = parts[0];
            String homeName = parts[1];

            Optional<GameProfile> profile = player.method_5682().method_3793().method_14515(ownerName);
            if (profile.isEmpty()) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }
            UUID ownerUUID = profile.get().getId();

            // Check if it's a public home
            java.util.Map<String, PublicHomeInfo> ownerPublicHomes = publicHomesByOwner.get(ownerUUID.toString());
            boolean isPublic = ownerPublicHomes != null && ownerPublicHomes.containsKey(homeName);

            // Check if it's a shared home
            Map<String, Home> homes = playerHomes.get(ownerUUID);
            if (homes == null || !homes.containsKey(homeName)) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }
            Home home = homes.get(homeName);

            if (!isPublic && !home.sharedPlayers.contains(player.method_5667())) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.other_not_found", "Home %s not found or not accessible!", homeArg
                ));
                return 0;
            }

            class_5321<class_1937> dimensionKey = class_5321.method_29179(class_7924.field_41223, home.position.dimension);
            class_3218 targetLevel = player.method_5682().method_3847(dimensionKey);
            if (targetLevel == null) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.invalid_dimension", "Invalid dimension for home %s!", homeArg
                ));
                return 0;
            }

            recordLastPosition(player);
            player.method_14251(
                    targetLevel,
                    home.position.x, home.position.y, home.position.z,
                    home.position.yRot, home.position.xRot
            );
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.other_teleported", "Teleported to %s's home %s.", ownerName, homeName
            ));
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.info("Player {} teleported to {}'s home {}", player.method_5477().getString(), ownerName, homeName);
            return 1;
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error executing /home otherhome {}: {}", homeArg, e.getMessage());
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }

    private static int listOtherHomes(class_3222 player) {
        try {
            if (publicHomesByOwner.isEmpty()) {
                player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                        "command.tpatool.home.otherlist_empty", "No public or shared homes available."
                ));
                return 0;
            }
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.home.otherlist", "Public homes:"
            ));

            for (java.util.Map.Entry<String, java.util.Map<String, PublicHomeInfo>> ownerEntry : publicHomesByOwner.entrySet()) {
                String ownerUUIDStr = ownerEntry.getKey();
                java.util.Map<String, PublicHomeInfo> homes = ownerEntry.getValue();

                UUID ownerUUID = UUID.fromString(ownerUUIDStr);
                String ownerName = player.method_5682().method_3793().method_14512(ownerUUID)
                        .map(GameProfile::getName).orElse("Unknown");

                for (java.util.Map.Entry<String, PublicHomeInfo> homeEntry : homes.entrySet()) {
                    String homeName = homeEntry.getKey();
                    PublicHomeInfo info = homeEntry.getValue();

                    Map<String, Home> ownerHomes = playerHomes.get(ownerUUID);
                    if (ownerHomes != null && ownerHomes.containsKey(homeName)) {
                        Home home = ownerHomes.get(homeName);
                        String dimensionName = home.position.dimension != null
                                ? home.position.dimension.toString()
                                : "unknown";
                        player.method_43496(class_2561.method_43470(String.format(
                                "- %s (%s): %s (x=%.2f, y=%.2f, z=%.2f)",
                                homeName, ownerName, dimensionName,
                                home.position.x, home.position.y, home.position.z
                        )));
                    }
                }
            }
            return 1;
        } catch (Exception e) {
            com.kicobicn.TPATools.config.ModConfigs.DebugLog.error("Error executing /home otherlist: {}", e.getMessage());
            player.method_43496(com.kicobicn.TPATools.config.ModConfigs.translateWithFallback(
                    "command.tpatool.error", "An unexpected error occurred while executing the command."
            ));
            return 0;
        }
    }
}
