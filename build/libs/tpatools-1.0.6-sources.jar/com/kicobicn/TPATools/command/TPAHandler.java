package com.kicobicn.TPATools.command;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.kicobicn.TPATools.config.ModConfigs;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static com.kicobicn.TPATools.config.ModConfigs.*;

public class TPAHandler {
    private static final Map<UUID, List<TPARequest>> requests = new HashMap<>();
    private static final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final Map<UUID, Boolean> toggleStates = new HashMap<>();
    private static final Map<UUID, Set<UUID>> lockedPlayers = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static class TPARequest {
        public final class_3222 sender;
        public final class_3222 target;
        public final boolean isTPHere;
        public final long timestamp;

        public TPARequest(class_3222 sender, class_3222 target, boolean isTPHere) {
            this.sender = sender;
            this.target = target;
            this.isTPHere = isTPHere;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public static void onServerStarting(MinecraftServer server) {
        ModConfigs.loadTranslations(ModConfigs.DEFAULT_LANGUAGE);
    }

    // Load command permissions
    public static void loadCommandPermissions() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Boolean> loadedPermissions = GSON.fromJson(jsonContent, java.util.Map.class);
                ModConfigs.commandPermissions.clear();
                if (loadedPermissions != null) {
                    ModConfigs.commandPermissions.putAll(loadedPermissions);
                    ModConfigs.DebugLog.info("Loaded command permissions from {}", path.toString());
                }
            }
            ModConfigs.initCommandPermissions();
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to load command permissions: {}", e.getMessage());
        }
    }

    // Save command permissions
    public static void saveCommandPermissions() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool.json");
            Files.writeString(path, GSON.toJson(ModConfigs.commandPermissions));
            ModConfigs.DebugLog.info("Saved command permissions to {}", path.toString());
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to save command permissions: {}", e.getMessage());
        }
    }

    // Load toggle states
    public static void loadToggleStates() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_toggles.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Boolean> loadedToggles = GSON.fromJson(jsonContent, java.util.Map.class);
                toggleStates.clear();
                if (loadedToggles != null) {
                    loadedToggles.forEach((uuidStr, state) -> toggleStates.put(UUID.fromString(uuidStr), state));
                    ModConfigs.DebugLog.info("Loaded toggle states from {}", path.toString());
                }
            }
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to load toggle states: {}", e.getMessage());
        }
    }

    // Save toggle states
    public static void saveToggleStates() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_toggles.json");
            Files.writeString(path, GSON.toJson(toggleStates));
            ModConfigs.DebugLog.info("Saved toggle states to {}", path.toString());
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to save toggle states: {}", e.getMessage());
        }
    }

    // Load locked players
    public static void loadLockedPlayers() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_locks.json");
            if (Files.exists(path)) {
                String jsonContent = Files.readString(path);
                java.util.Map<String, Set<String>> loadedLocks = GSON.fromJson(jsonContent, java.util.Map.class);
                lockedPlayers.clear();
                if (loadedLocks != null) {
                    loadedLocks.forEach((uuidStr, locks) -> {
                        UUID playerUuid = UUID.fromString(uuidStr);
                        Set<UUID> uuidLocks = new HashSet<>();
                        if (locks != null) {
                            for (String lockStr : locks) {
                                uuidLocks.add(UUID.fromString(lockStr));
                            }
                        }
                        lockedPlayers.put(playerUuid, uuidLocks);
                    });
                    ModConfigs.DebugLog.info("Loaded locked players from {}", path.toString());
                }
            }
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to load locked players: {}", e.getMessage());
        }
    }

    // Save locked players
    public static void saveLockedPlayers() {
        try {
            Path path = ModConfigs.getConfigDir().resolve("tpatool_locks.json");
            Files.writeString(path, GSON.toJson(lockedPlayers));
            ModConfigs.DebugLog.info("Saved locked players to {}", path.toString());
        } catch (IOException e) {
            ModConfigs.DebugLog.error("Failed to save locked players: {}", e.getMessage());
        }
    }

    public static void registerCommands(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
        // tpa 指令
        dispatcher.register(
                class_2170.method_9247("tpa")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 sender = context.getSource().method_9207();
                                        class_3222 target = class_2186.method_9315(context, "player");
                                        return sendTPARequest(sender, target, false);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpa: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    } catch (Exception e) {
                                        ModConfigs.DebugLog.error("Unexpected error in /tpa: ", e);
                                        context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpahere 指令
        dispatcher.register(
                class_2170.method_9247("tpahere")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 sender = context.getSource().method_9207();
                                        class_3222 target = class_2186.method_9315(context, "player");
                                        return sendTPARequest(sender, target, true);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpahere: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    } catch (Exception e) {
                                        ModConfigs.DebugLog.error("Unexpected error in /tpahere: ", e);
                                        context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpaccept 指令
        dispatcher.register(
                class_2170.method_9247("tpaccept")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .executes(context -> {
                            try {
                                return acceptTPARequest(context.getSource().method_9207(), null);
                            } catch (CommandSyntaxException e) {
                                context.getSource().method_9213(class_2561.method_43470("This command can only be used by players."));
                                return 0;
                            }
                        })
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 sender = class_2186.method_9315(context, "player");
                                        return acceptTPARequest(context.getSource().method_9207(), sender);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpaccept: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpadeny 指令
        dispatcher.register(
                class_2170.method_9247("tpadeny")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .executes(context -> {
                            try {
                                return denyTPARequest(context.getSource().method_9207(), null);
                            } catch (CommandSyntaxException e) {
                                context.getSource().method_9213(class_2561.method_43470("This command can only be used by players."));
                                return 0;
                            }
                        })
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 sender = class_2186.method_9315(context, "player");
                                        return denyTPARequest(context.getSource().method_9207(), sender);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpadeny: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpacancel 指令
        dispatcher.register(
                class_2170.method_9247("tpacancel")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .executes(context -> {
                            try {
                                return cancelTPARequest(context.getSource().method_9207(), null);
                            } catch (CommandSyntaxException e) {
                                context.getSource().method_9213(class_2561.method_43470("This command can only be used by players."));
                                return 0;
                            }
                        })
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 target = class_2186.method_9315(context, "player");
                                        return cancelTPARequest(context.getSource().method_9207(), target);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpacancel: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpatoggle 指令 - 修复这里
        dispatcher.register(
                class_2170.method_9247("tpatoggle")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .executes(context -> {
                            try {
                                return toggleTPA(context.getSource().method_9207());
                            } catch (CommandSyntaxException e) {
                                context.getSource().method_9213(class_2561.method_43470("This command can only be used by players."));
                                return 0;
                            }
                        })
        );

        // tpalock 指令
        dispatcher.register(
                class_2170.method_9247("tpalock")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 target = class_2186.method_9315(context, "player");
                                        return lockTPA(context.getSource().method_9207(), target);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpalock: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    }
                                })
                        )
        );

        // tpaunlock 指令
        dispatcher.register(
                class_2170.method_9247("tpaunlock")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "tpa"))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> {
                                    try {
                                        class_3222 target = class_2186.method_9315(context, "player");
                                        return unlockTPA(context.getSource().method_9207(), target);
                                    } catch (CommandSyntaxException e) {
                                        ModConfigs.DebugLog.error("Failed to parse /tpaunlock: {}", e.getMessage());
                                        context.getSource().method_9213(class_2561.method_43470("Invalid player name."));
                                        return 0;
                                    }
                                })
                        )
        );
    }

    private static int sendTPARequest(class_3222 sender, class_3222 target, boolean isTPHere) {
        if (sender == target) {
            sender.method_43496(translateWithFallback("command.tpatool.tpa.self", "You cannot teleport to yourself!"));
            return 0;
        }

        Long lastRequest = cooldowns.get(sender.method_5667());
        long currentTime = System.currentTimeMillis();
        long cooldownMs = COOLDOWN_TIME;

        if (lastRequest != null && currentTime - lastRequest < cooldownMs) {
            long remainingSeconds = (cooldownMs - (currentTime - lastRequest)) / 1000;
            sender.method_43496(translateWithFallback(
                    "command.tpatool.tpa.cooldown",
                    "Please wait for the cooldown (%d seconds)!",
                    remainingSeconds
            ));
            return 0;
        }
        if (!target.method_5805()) {
            sender.method_43496(translateWithFallback("command.tpatool.tpa.target_dead", "The target player is dead!"));
            return 0;
        }
        if (toggleStates.getOrDefault(target.method_5667(), false)) {
            sender.method_43496(translateWithFallback("command.tpatool.tpa.toggled_off", "%s has disabled TPA requests.", target.method_5477()));
            return 0;
        }
        Set<UUID> lockedByTarget = lockedPlayers.getOrDefault(target.method_5667(), new HashSet<>());
        if (lockedByTarget.contains(sender.method_5667())) {
            sender.method_43496(translateWithFallback("command.tpatool.tpa.locked", "%s has locked TPA requests from you.", target.method_5477()));
            return 0;
        }

        // 检查是否已存在来自同一发送者的请求，如果存在则更新，否则添加新请求
        List<TPARequest> targetRequests = requests.computeIfAbsent(target.method_5667(), k -> new ArrayList<>());
        TPARequest existingRequest = null;
        for (TPARequest req : targetRequests) {
            if (req.sender.method_5667().equals(sender.method_5667())) {
                existingRequest = req;
                break;
            }
        }

        TPARequest request;
        if (existingRequest != null) {
            // 更新现有请求（刷新时间戳，保持其他属性不变）
            // 从列表中移除旧请求
            targetRequests.remove(existingRequest);
            // 创建新请求，使用新的时间戳
            request = new TPARequest(sender, target, isTPHere);
            // 发送更新提示
            sender.method_43496(translateWithFallback("command.tpatool.tpa.request_updated", "Teleport request updated to %s.", target.method_5477()));
        } else {
            // 创建新请求
            request = new TPARequest(sender, target, isTPHere);
            sender.method_43496(translateWithFallback("command.tpatool.tpa.sent", "Teleport request sent to %s.", target.method_5477()));
        }

        // 添加请求到列表
        targetRequests.add(request);

        String senderName = sender.method_5477().getString();
        class_5250 acceptText = class_2561.method_43470("[" + translations.getOrDefault("command.tpatool.tpa.accept", "Accept") + " " + senderName + "]")
                .method_27694(style -> style.method_10958(new class_2558(class_2558.class_2559.field_11750, "/tpaccept " + senderName))
                        .method_10977(class_124.field_1060));
        class_5250 denyText = class_2561.method_43470("[" + translations.getOrDefault("command.tpatool.tpa.deny", "Deny") + " " + senderName + "]")
                .method_27694(style -> style.method_10958(new class_2558(class_2558.class_2559.field_11750, "/tpadeny " + senderName))
                        .method_10977(class_124.field_1061));
        class_5250 message = translateWithFallback(
                isTPHere ? "command.tpatool.tpahere.received" : "command.tpatool.tpa.received",
                isTPHere ? "%s wants you to teleport to them! Click to accept or deny." : "%s wants to teleport to you! Click to accept or deny.",
                sender.method_5477()
        ).method_10852(class_2561.method_43470("\n")).method_10852(acceptText).method_10852(class_2561.method_43470(" ")).method_10852(denyText);

        target.method_43496(message);
        cooldowns.put(sender.method_5667(), System.currentTimeMillis());
        ModConfigs.DebugLog.log("{} request sent/updated: {} -> {}", isTPHere ? "TPAHere" : "TPA", senderName, target.method_5477().getString());
        return 1;
    }

    private static int acceptTPARequest(class_3222 target, class_3222 sender) {
        List<TPARequest> targetRequests = requests.get(target.method_5667());
        if (targetRequests == null || targetRequests.isEmpty()) {
            target.method_43496(translateWithFallback("command.tpatool.tpa.no_request", "You have no pending teleport requests."));
            return 0;
        }
        TPARequest request;
        if (sender != null) {
            request = targetRequests.stream()
                    .filter(req -> req.sender.method_5667().equals(sender.method_5667()))
                    .findFirst()
                    .orElse(null);
            if (request == null) {
                target.method_43496(translateWithFallback("command.tpatool.tpa.no_request_from", "No teleport request from %s.", sender.method_5477()));
                return 0;
            }
        } else {
            request = targetRequests.get(targetRequests.size() - 1);
        }
        if (!request.sender.method_5805()) {
            target.method_43496(translateWithFallback("command.tpatool.tpa.sender_dead", "The requesting player is dead!"));
            targetRequests.remove(request);
            if (targetRequests.isEmpty()) {
                requests.remove(target.method_5667());
            }
            return 0;
        }
        if (request.isTPHere) {
            com.kicobicn.TPATools.command.BackHandler.PlayerPosition currentPosition = new com.kicobicn.TPATools.command.BackHandler.PlayerPosition(
                    target.method_51469(),
                    target.method_23317(), target.method_23318(), target.method_23321(),
                    target.method_36454(), target.method_36455()
            );
            target.method_14251(
                    request.sender.method_51469(),
                    request.sender.method_23317(), request.sender.method_23318(), request.sender.method_23321(),
                    request.sender.method_36454(), request.sender.method_36455()
            );
            com.kicobicn.TPATools.command.BackHandler.previousPositions.put(target.method_5667(), currentPosition);
        } else {
            com.kicobicn.TPATools.command.BackHandler.PlayerPosition currentPosition = new com.kicobicn.TPATools.command.BackHandler.PlayerPosition(
                    request.sender.method_51469(),
                    request.sender.method_23317(), request.sender.method_23318(), request.sender.method_23321(),
                    request.sender.method_36454(), request.sender.method_36455()
            );
            request.sender.method_14251(
                    target.method_51469(),
                    target.method_23317(), target.method_23318(), target.method_23321(),
                    target.method_36454(), target.method_36455()
            );
            com.kicobicn.TPATools.command.BackHandler.previousPositions.put(request.sender.method_5667(), currentPosition);
        }
        target.method_43496(translateWithFallback(
                request.isTPHere ? "command.tpatool.tpahere.accepted" : "command.tpatool.tpa.accepted",
                request.isTPHere ? "Accepted teleport request to %s." : "Accepted teleport request from %s.",
                request.sender.method_5477()
        ));
        request.sender.method_43496(translateWithFallback(
                "command.tpatool.tpa.accepted_by",
                "Your teleport request was accepted by %s!", target.method_5477()
        ));
        targetRequests.remove(request);
        if (targetRequests.isEmpty()) {
            requests.remove(target.method_5667());
        }
        ModConfigs.DebugLog.log("TPA request accepted: {} teleported to {}",
                request.isTPHere ? target.method_5477().getString() : request.sender.method_5477().getString(),
                request.isTPHere ? request.sender.method_5477().getString() : target.method_5477().getString());
        return 1;
    }

    private static int denyTPARequest(class_3222 target, class_3222 sender) {
        List<TPARequest> targetRequests = requests.get(target.method_5667());
        if (targetRequests == null || targetRequests.isEmpty()) {
            target.method_43496(translateWithFallback("command.tpatool.tpa.no_request", "You have no pending teleport requests."));
            return 0;
        }
        TPARequest request;
        if (sender != null) {
            request = targetRequests.stream()
                    .filter(req -> req.sender.method_5667().equals(sender.method_5667()))
                    .findFirst()
                    .orElse(null);
            if (request == null) {
                target.method_43496(translateWithFallback("command.tpatool.tpa.no_request_from", "No teleport request from %s.", sender.method_5477()));
                return 0;
            }
        } else {
            request = targetRequests.get(targetRequests.size() - 1);
        }
        target.method_43496(translateWithFallback(
                request.isTPHere ? "command.tpatool.tpahere.denied" : "command.tpatool.tpa.denied",
                request.isTPHere ? "Denied teleport request to %s." : "Denied teleport request from %s.",
                request.sender.method_5477()
        ));
        request.sender.method_43496(translateWithFallback(
                "command.tpatool.tpa.denied_by",
                "%s denied your teleport request.", target.method_5477()
        ));
        targetRequests.remove(request);
        if (targetRequests.isEmpty()) {
            requests.remove(target.method_5667());
        }
        ModConfigs.DebugLog.info("TPA request denied: {} -> {}", request.sender.method_5477().getString(), target.method_5477().getString());
        return 1;
    }

    private static int cancelTPARequest(class_3222 sender, class_3222 target) {
        boolean cancelled = false;
        for (List<TPARequest> targetRequests : requests.values()) {
            Iterator<TPARequest> iterator = targetRequests.iterator();
            while (iterator.hasNext()) {
                TPARequest request = iterator.next();
                if (request.sender.method_5667().equals(sender.method_5667()) && (target == null || request.target.method_5667().equals(target.method_5667()))) {
                    iterator.remove();
                    request.target.method_43496(translateWithFallback(
                            "command.tpatool.tpa.cancelled", "%s cancelled their teleport request.", sender.method_5477()
                    ));
                    sender.method_43496(translateWithFallback(
                            "command.tpatool.tpa.cancelled_self", "Cancelled teleport request to %s.", request.target.method_5477()
                    ));
                    ModConfigs.DebugLog.info("TPA request cancelled: {} -> {}", sender.method_5477().getString(), request.target.method_5477().getString());
                    cancelled = true;
                }
            }
        }
        requests.entrySet().removeIf(entry -> entry.getValue().isEmpty());
        if (!cancelled) {
            sender.method_43496(translateWithFallback(
                    "command.tpatool.tpa.no_requests_to_cancel", "No teleport requests to cancel."
            ));
            return 0;
        }
        return 1;
    }

    private static int toggleTPA(class_3222 player) {
        boolean currentState = toggleStates.getOrDefault(player.method_5667(), false);
        boolean newState = !currentState;
        toggleStates.put(player.method_5667(), newState);
        saveToggleStates();
        player.method_43496(translateWithFallback(
                "command.tpatool.tpa.toggle_" + (newState ? "on" : "off"),
                newState ? "TPA requests are now disabled." : "TPA requests are now enabled."
        ));
        ModConfigs.DebugLog.info("Player {} toggled TPA to {}", player.method_5477().getString(), newState ? "off" : "on");
        return 1;
    }

    private static int lockTPA(class_3222 player, class_3222 target) {
        if (player == target) {
            player.method_43496(translateWithFallback("command.tpatool.tpa.lock_self", "You cannot lock yourself!"));
            return 0;
        }
        Set<UUID> locked = lockedPlayers.computeIfAbsent(player.method_5667(), k -> new HashSet<>());
        if (locked.contains(target.method_5667())) {
            player.method_43496(translateWithFallback("command.tpatool.tpa.already_locked", "%s is already locked.", target.method_5477()));
            return 0;
        }
        locked.add(target.method_5667());
        saveLockedPlayers();
        player.method_43496(translateWithFallback("command.tpatool.tpa.locked_player", "Locked TPA requests from %s.", target.method_5477()));
        ModConfigs.DebugLog.info("Player {} locked TPA from {}", player.method_5477().getString(), target.method_5477().getString());
        return 1;
    }

    private static int unlockTPA(class_3222 player, class_3222 target) {
        if (player == target) {
            player.method_43496(translateWithFallback("command.tpatool.tpa.lock_self", "You cannot unlock yourself!"));
            return 0;
        }
        Set<UUID> locked = lockedPlayers.get(player.method_5667());
        if (locked == null || !locked.contains(target.method_5667())) {
            player.method_43496(translateWithFallback("command.tpatool.tpa.not_locked", "%s is not locked.", target.method_5477()));
            return 0;
        }
        locked.remove(target.method_5667());
        if (locked.isEmpty()) {
            lockedPlayers.remove(player.method_5667());
        }
        saveLockedPlayers();
        player.method_43496(translateWithFallback("command.tpatool.tpa.unlocked_player", "Unlocked TPA requests from %s.", target.method_5477()));
        ModConfigs.DebugLog.info("Player {} unlocked TPA from {}", player.method_5477().getString(), target.method_5477().getString());
        return 1;
    }

    public static void tick() {
        List<UUID> toRemove = new ArrayList<>();
        for (Map.Entry<UUID, List<TPARequest>> entry : requests.entrySet()) {
            Iterator<TPARequest> iterator = entry.getValue().iterator();
            while (iterator.hasNext()) {
                TPARequest request = iterator.next();
                if (System.currentTimeMillis() - request.timestamp >= TIMEOUT_TICKS * 50) {
                    request.target.method_43496(translateWithFallback(
                            request.isTPHere ? "command.tpatool.tpahere.timeout" : "command.tpatool.tpa.timeout",
                            "Teleport request from %s has timed out.", request.sender.method_5477()
                    ));
                    request.sender.method_43496(translateWithFallback(
                            "command.tpatool.tpa.timeout_self",
                            "Your teleport request to %s has timed out.", request.target.method_5477()
                    ));
                    iterator.remove();
                    ModConfigs.DebugLog.info("TPA request timed out: {} -> {}",
                            request.sender.method_5477().getString(), request.target.method_5477().getString());
                }
            }
            if (entry.getValue().isEmpty()) {
                toRemove.add(entry.getKey());
            }
        }
        toRemove.forEach(requests::remove);
    }
}