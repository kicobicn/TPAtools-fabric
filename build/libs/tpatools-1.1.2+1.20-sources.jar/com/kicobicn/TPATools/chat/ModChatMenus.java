package com.kicobicn.TPATools.chat;

import com.kicobicn.TPATools.Commands.HomeHandler;
import com.kicobicn.TPATools.Commands.WarpHandler;
import com.kicobicn.TPATools.config.ModConfigs;
import com.kicobicn.TPATools.util.ModUtils;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.network.chat.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ModChatMenus {

    // 存储玩家的UI状态
    private static final Map<UUID, UIState> playerUIStates = new ConcurrentHashMap<>();

    // UI状态类
    private static class UIState {
        String currentMenu;
        List<String> menuData;

        public UIState(String currentMenu, List<String> menuData) {
            this.currentMenu = currentMenu;
            this.menuData = menuData;
        }
    }

    public static class HomeMenus {

        public static void showHomeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - Home ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.home.title.main", "        -Home menu -\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

                    // 按钮
                    menu.method_10852(createI18nButton("menu.tpatools.home.button.sethome",
                                    "menu.tpatools.home.hover.sethome",
                                    "/home set ",
                                    class_124.field_1060,
                                    false))
                            .method_10852(class_2561.method_43470("\n"));
            
                    menu.method_10852(createI18nButton("menu.tpatools.home.button.managehome",
                                    "menu.tpatools.home.hover.managehome",
                                    "/home list",
                                    class_124.field_1075,
                                    true))
                            .method_10852(class_2561.method_43470(" "))
                            .method_10852(createI18nButton("menu.tpatools.home.button.visitother",
                                    "menu.tpatools.home.hover.visitother",
                                    "/home otherlist",
                                    class_124.field_1075,
                                    true))
                            .method_10852(class_2561.method_43470("\n"));
            
                    menu.method_10852(createI18nButton("menu.tpatools.home.button.sharedouthomes",
                                    "menu.tpatools.home.hover.sharedouthomes",
                                    "/home sharelist out",
                                    class_124.field_1075,
                                    true))
                            .method_10852(class_2561.method_43470(" "))
                            .method_10852(createI18nButton("menu.tpatools.home.button.sharedinhomes",
                                    "menu.tpatools.home.hover.sharedinhomes",
                                    "/home sharelist in",
                                    class_124.field_1075,
                                    true))
                            .method_10852(class_2561.method_43470("\n"));
            // 分割线
            menu.method_10852(class_2561.method_43470("==============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showOwnHomesList(class_3222 player, int page) {
            Map<String, HomeHandler.Home> homes = HomeHandler.playerHomes.get(player.method_5667());
            if (homes == null || homes.isEmpty()) {
                player.method_43496(ModUtils.translateWithFallback(
                        "command.tpatool.home.list_empty", "You have no homes set."));
                return;
            }

            List<String> homeNames = new ArrayList<>(homes.keySet());
            int pageSize = 5;
            int totalPages = (int) Math.ceil((double) homeNames.size() / pageSize);
            page = Math.max(0, Math.min(page, totalPages - 1));

            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - Home/list ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.home.title.homelist", "        - Your Current Homes -\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

            // 显示当前页的家
            int startIndex = page * pageSize;
            int endIndex = Math.min(startIndex + pageSize, homeNames.size());

            for (int i = startIndex; i < endIndex; i++) {
                String homeName = homeNames.get(i);
                HomeHandler.Home home = homes.get(homeName);

                menu.method_10852(class_2561.method_43470("- " + homeName + "\n")
                        .method_27692(class_124.field_1068));

                String position = String.format("%s (x=%.2f, y=%.2f, z=%.2f)",
                        home.position.dimension, home.position.x, home.position.y, home.position.z);
                menu.method_10852(class_2561.method_43470("  " + position + "\n")
                        .method_27692(class_124.field_1080));

                                // 按钮行
                                class_5250 buttons = class_2561.method_43470(" ");
                                buttons.method_10852(createI18nButton("menu.tpatools.home.button.teleport",
                                                "menu.tpatools.home.hover.teleport",
                                                "/home tp " + homeName,
                                                class_124.field_1060,
                                                true))
                                        .method_10852(class_2561.method_43470(" "));
                                buttons.method_10852(createI18nButton("menu.tpatools.home.button.rename",
                                                "menu.tpatools.home.hover.rename",
                                                "/home rename " + homeName + " ",
                                                class_124.field_1054,
                                                false))
                                        .method_10852(class_2561.method_43470(" "));

                                // 公开/私密按钮
                                Map<String, HomeHandler.PublicHomeInfo> publicHomes = HomeHandler.publicHomesByOwner.get(player.method_5667().toString());
                                boolean isPublic = publicHomes != null && publicHomes.containsKey(homeName);
                                String publicCommand = isPublic ? "/home private " + homeName : "/home public " + homeName;
                                String publicText = isPublic ? "menu.tpatools.home.button.setprivate" : "menu.tpatools.home.button.setpublic";
                                String publicHover = isPublic ? "menu.tpatools.home.hover.setprivate" : "menu.tpatools.home.hover.setpublic";
                                class_124 publicColor = isPublic ? class_124.field_1061 : class_124.field_1060;

                                buttons.method_10852(createI18nButton(publicText,
                                                publicHover,
                                                publicCommand,
                                                publicColor,
                                                true))
                                        .method_10852(class_2561.method_43470(" "));

                                // 分享按钮
                                int sharedCount = home.sharedPlayers.size();
                                buttons.method_10852(createI18nButtonWithHoverArgs("menu.tpatools.home.button.share",
                                                "menu.tpatools.home.hover.share",
                                                "/home share " + homeName + " ",
                                                class_124.field_1075,
                                                false,
                                                new Object[]{sharedCount},
                                                new Object[]{sharedCount}))
                                        .method_10852(class_2561.method_43470(" "));

                                buttons.method_10852(createI18nButton("menu.tpatools.home.button.invite",
                                                "menu.tpatools.home.hover.invite",
                                                "/home invite invite " + homeName + " ",
                                                class_124.field_1076,
                                                false))
                                        .method_10852(class_2561.method_43470(" "));

                                buttons.method_10852(createI18nButton("menu.tpatools.home.button.delete",
                                                "menu.tpatools.home.hover.delete",
                                                "/home remove " + homeName,
                                                class_124.field_1061,
                                                true))
                                        .method_10852(class_2561.method_43470(" "));
                menu.method_10852(buttons).method_10852(class_2561.method_43470("\n"));
            }

            // 分页系统
            if (totalPages > 1) {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));

                class_5250 pagination = class_2561.method_43470(" ");
                pagination.method_10852(createI18nButton("menu.tpatools.home.button.previouspage",
                                "menu.tpatools.home.hover.previouspage",
                                "/home list page " + Math.max(0, page - 1),
                                class_124.field_1080,
                                true))
                        .method_10852(class_2561.method_43470(" - " + (page + 1) + "/" + totalPages + " - "))
                        .method_10852(createI18nButton("menu.tpatools.home.button.nextpage",
                                "menu.tpatools.home.hover.nextpage",
                                "/home list page " + Math.min(totalPages - 1, page + 1),
                                class_124.field_1080,
                                true));

                menu.method_10852(pagination).method_10852(class_2561.method_43470("\n"));
            } else {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));
            }

            player.method_43496(menu);
        }

        public static void showSharedOutList(class_3222 player, int page) {
            Map<String, HomeHandler.Home> homes = HomeHandler.playerHomes.get(player.method_5667());
            if (homes == null || homes.isEmpty()) {
                player.method_43496(ModUtils.translateWithFallback(
                        "command.tpatool.sharelist.out_empty", "You have not shared any homes."));
                return;
            }

            List<String> sharedHomeNames = new ArrayList<>();
            for (Map.Entry<String, HomeHandler.Home> entry : homes.entrySet()) {
                if (!entry.getValue().sharedPlayers.isEmpty()) {
                    sharedHomeNames.add(entry.getKey());
                }
            }

            if (sharedHomeNames.isEmpty()) {
                player.method_43496(ModUtils.translateWithFallback(
                        "command.tpatool.sharelist.out_empty", "You have not shared any homes."));
                return;
            }

            int pageSize = 5;
            int totalPages = (int) Math.ceil((double) sharedHomeNames.size() / pageSize);
            page = Math.max(0, Math.min(page, totalPages - 1));

            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - Home/sharelist/out =====\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.home.title.sharelist_out", "        - Homes You've Shared -\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

            // 显示当前页的分享家
            int startIndex = page * pageSize;
            int endIndex = Math.min(startIndex + pageSize, sharedHomeNames.size());

            for (int i = startIndex; i < endIndex; i++) {
                String homeName = sharedHomeNames.get(i);
                HomeHandler.Home home = homes.get(homeName);

                menu.method_10852(class_2561.method_43470("- " + homeName + "\n")
                        .method_27692(class_124.field_1068));

                String position = String.format("%s (x=%.2f, y=%.2f, z=%.2f)",
                        home.position.dimension, home.position.x, home.position.y, home.position.z);
                menu.method_10852(class_2561.method_43470("  " + position + "\n")
                        .method_27692(class_124.field_1080));

                // 显示分享的玩家
                List<String> sharedPlayerNames = new ArrayList<>();
                for (UUID sharedUUID : home.sharedPlayers) {
                    String playerName = player.method_5682().method_3793().method_14512(sharedUUID)
                            .map(GameProfile::getName).orElse("Unknown");
                    sharedPlayerNames.add(playerName);
                }
                menu.method_10852(class_2561.method_43470("  已分享给：" + String.join(" ", sharedPlayerNames) + "\n")
                        .method_27692(class_124.field_1080));

                // 按钮行
                class_5250 buttons = class_2561.method_43470("  ");
                buttons.method_10852(createI18nButton("menu.tpatools.home.button.cancelallshare",
                                "menu.tpatools.home.hover.cancelallshare",
                                "/home unshare " + homeName,
                                class_124.field_1061,
                                true))
                        .method_10852(class_2561.method_43470(" "));

                buttons.method_10852(createI18nButton("menu.tpatools.home.button.cancelplayershare",
                                "menu.tpatools.home.hover.cancelplayershare",
                                "/home unshare " + homeName + " ",
                                class_124.field_1054,
                                false))
                        .method_10852(class_2561.method_43470("\n\n"));

                menu.method_10852(buttons);
            }

            // 分页系统
            if (totalPages > 1) {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));

                class_5250 pagination = class_2561.method_43470(" ");
                pagination.method_10852(createI18nButton("menu.tpatools.home.button.previouspage",
                                "menu.tpatools.home.hover.previouspage",
                                "/home sharelist out page " + Math.max(0, page - 1),
                                class_124.field_1080,
                                true))
                        .method_10852(class_2561.method_43470(" - " + (page + 1) + "/" + totalPages + " - "))
                        .method_10852(createI18nButton("menu.tpatools.home.button.nextpage",
                                "menu.tpatools.home.hover.nextpage",
                                "/home sharelist out page " + Math.min(totalPages - 1, page + 1),
                                class_124.field_1080,
                                true));

                menu.method_10852(pagination).method_10852(class_2561.method_43470("\n"));
            } else {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));
            }

            player.method_43496(menu);
        }

        public static void showPublicHomesList(class_3222 player, int page) {
            if (HomeHandler.publicHomesByOwner.isEmpty()) {
                player.method_43496(ModUtils.translateWithFallback(
                        "command.tpatool.home.otherlist_empty", "No public or shared homes available."));
                return;
            }

            List<HomeHandler.PublicHomeInfo> publicHomes = new ArrayList<>();
            for (Map.Entry<String, Map<String, HomeHandler.PublicHomeInfo>> ownerEntry : HomeHandler.publicHomesByOwner.entrySet()) {
                for (HomeHandler.PublicHomeInfo info : ownerEntry.getValue().values()) {
                    publicHomes.add(info);
                }
            }

            int pageSize = 5;
            int totalPages = (int) Math.ceil((double) publicHomes.size() / pageSize);
            page = Math.max(0, Math.min(page, totalPages - 1));

            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - Home/otherlist ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.home.title.otherlist", "        - Public Homes Available -\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

            // 显示当前页的公开家
            int startIndex = page * pageSize;
            int endIndex = Math.min(startIndex + pageSize, publicHomes.size());

            for (int i = startIndex; i < endIndex; i++) {
                HomeHandler.PublicHomeInfo info = publicHomes.get(i);
                Map<String, HomeHandler.Home> ownerHomes = HomeHandler.playerHomes.get(info.ownerUUID);

                if (ownerHomes != null && ownerHomes.containsKey(info.homeName)) {
                    HomeHandler.Home home = ownerHomes.get(info.homeName);

                    menu.method_10852(class_2561.method_43470("- " + info.homeName + "，拥有者 " + info.ownerName + "\n")
                            .method_27692(class_124.field_1068));

                    String position = String.format("%s (x=%.2f, y=%.2f, z=%.2f)",
                            home.position.dimension, home.position.x, home.position.y, home.position.z);
                    menu.method_10852(class_2561.method_43470("  " + position + "\n")
                            .method_27692(class_124.field_1080));

                    // 传送按钮
                    menu.method_10852(class_2561.method_43470("  "))
                            .method_10852(createI18nButton("menu.tpatools.home.button.teleport",
                                    "menu.tpatools.home.hover.teleport",
                                    "/home otherhome " + info.ownerName + ":" + info.homeName,
                                    class_124.field_1060,
                                    true))
                            .method_10852(class_2561.method_43470("\n\n"));
                }
            }

            // 分页系统
            if (totalPages > 1) {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));

                class_5250 pagination = class_2561.method_43470(" ");
                pagination.method_10852(createI18nButton("menu.tpatools.home.button.previouspage",
                                "menu.tpatools.home.hover.previouspage",
                                "/home otherlist page " + Math.max(0, page - 1),
                                class_124.field_1080,
                                true))
                        .method_10852(class_2561.method_43470(" - " + (page + 1) + "/" + totalPages + " - "))
                        .method_10852(createI18nButton("menu.tpatools.home.button.nextpage",
                                "menu.tpatools.home.hover.nextpage",
                                "/home otherlist page " + Math.min(totalPages - 1, page + 1),
                                class_124.field_1080,
                                true));

                menu.method_10852(pagination).method_10852(class_2561.method_43470("\n"));
            } else {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));
            }

            player.method_43496(menu);
        }

        public static void showSharedInList(class_3222 player, int page) {
            List<HomeHandler.Home> sharedHomes = new ArrayList<>();
            List<String> ownerNames = new ArrayList<>();

            for (Map.Entry<UUID, Map<String, HomeHandler.Home>> entry : HomeHandler.playerHomes.entrySet()) {
                UUID ownerUUID = entry.getKey();
                if (!ownerUUID.equals(player.method_5667())) {
                    for (Map.Entry<String, HomeHandler.Home> homeEntry : entry.getValue().entrySet()) {
                        if (homeEntry.getValue().sharedPlayers.contains(player.method_5667())) {
                            sharedHomes.add(homeEntry.getValue());
                            String ownerName = player.method_5682().method_3793().method_14512(ownerUUID)
                                    .map(profile -> profile.getName()).orElse("Unknown");
                            ownerNames.add(ownerName + ":" + homeEntry.getKey());
                        }
                    }
                }
            }

            if (sharedHomes.isEmpty()) {
                player.method_43496(ModUtils.translateWithFallback(
                        "command.tpatool.sharelist.in_empty", "No homes are shared with you."));
                return;
            }

            int pageSize = 5;
            int totalPages = (int) Math.ceil((double) sharedHomes.size() / pageSize);
            page = Math.max(0, Math.min(page, totalPages - 1));

            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - Home/sharelist/in ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.home.title.sharelist_in", "        - Homes Shared With You -\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

            // 显示当前页的分享家
            int startIndex = page * pageSize;
            int endIndex = Math.min(startIndex + pageSize, sharedHomes.size());

            for (int i = startIndex; i < endIndex; i++) {
                HomeHandler.Home home = sharedHomes.get(i);
                String ownerHomeName = ownerNames.get(i);

                String[] parts = ownerHomeName.split(":", 2);
                String ownerName = parts[0];
                String homeName = parts[1];

                menu.method_10852(class_2561.method_43470("- " + homeName + " ,拥有者:" + ownerName + "\n")
                        .method_27692(class_124.field_1068));

                String position = String.format("%s (x=%.2f, y=%.2f, z=%.2f)",
                        home.position.dimension, home.position.x, home.position.y, home.position.z);
                menu.method_10852(class_2561.method_43470("  " + position + "\n")
                        .method_27692(class_124.field_1080));

                // 传送按钮
                menu.method_10852(class_2561.method_43470("  "))
                        .method_10852(createI18nButton("menu.tpatools.home.button.teleport",
                                "menu.tpatools.home.hover.teleport",
                                "/home otherhome " + ownerHomeName,
                                class_124.field_1060,
                                true))
                        .method_10852(class_2561.method_43470("\n\n"));
            }

            // 分页系统
            if (totalPages > 1) {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));

                class_5250 pagination = class_2561.method_43470(" ");
                pagination.method_10852(createI18nButton("menu.tpatools.home.button.previouspage",
                                "menu.tpatools.home.hover.previouspage",
                                "/home sharelist in page " + Math.max(0, page - 1),
                                class_124.field_1080,
                                true))
                        .method_10852(class_2561.method_43470(" - " + (page + 1) + "/" + totalPages + " - "))
                        .method_10852(createI18nButton("menu.tpatools.home.button.nextpage",
                                "menu.tpatools.home.hover.nextpage",
                                "/home sharelist in page " + Math.min(totalPages - 1, page + 1),
                                class_124.field_1080,
                                true));

                menu.method_10852(pagination).method_10852(class_2561.method_43470("\n"));
            } else {
                menu.method_10852(class_2561.method_43470("=============================\n")
                        .method_27692(class_124.field_1065));
            }

            player.method_43496(menu);
        }
    }

    public static class ConfigMenus {

        public static void showSettingsMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.title.main", "TPATools Control Panel\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(class_2561.method_43470("\n"));

            // 按钮

            if (player.method_5687(2)) {
                menu.method_10852(createI18nButton("menu.tpatools.config.button.configmenu",
                                "menu.tpatools.config.hover.configmenu",
                                "/tpatools configs",
                                class_124.field_1075,
                                true))
                        .method_10852(class_2561.method_43470(" "))
                        .method_10852(createI18nButton("menu.tpatools.config.button.debugmode",
                                "menu.tpatools.config.hover.debugmode",
                                "/tpatools debug",
                                class_124.field_1054,
                                true))
                        .method_10852(class_2561.method_43470(" "));
                }

                    menu.method_10852(createI18nButton("menu.tpatools.config.button.about",
                            "menu.tpatools.config.hover.about",
                            "/tpatools about",
                            class_124.field_1076,
                            true))
                    .method_10852(class_2561.method_43470("\n"));
            // 分割线
            menu.method_10852(class_2561.method_43470("=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showConfigsMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.setlanguage", "- Set Language (setlanguage)\n")
                            .method_27692(class_124.field_1068));

            class_124 langColor = "zh_cn".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_1",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage zh_cn",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            langColor = "en_us".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_2",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage en_us",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            langColor = "fr_fr".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_3",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage fr_fr",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            langColor = "es_es".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_4",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage es_es",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            langColor = "pt_br".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_5",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage pt_br",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            langColor = "zh_cn_cute".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_6",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage zh_cn_cute",
                            langColor,
                            true))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.setmaxhome", "- Set Maximum Number of Homes (setmaxhome)\n")
                    .method_27692(class_124.field_1068));

            int maxHomes = ModConfigs.MAX_HOMES.getAsInt();
            class_124 color2 = maxHomes == 2 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_2",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome 2",
                            color2,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            color2 = maxHomes == 3 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_3",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome 3",
                            color2,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            color2 = maxHomes == 5 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_5",
                            "menu.tpatools.config.hover.sethomemax",
                            "/tpatools configs setmaxhome 5",
                            color2,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.needop", "- Configure Whether Specific Commands Require OP (needop)\n")
                    .method_27692(class_124.field_1068));

            class_124 tpaColor = ModConfigs.commandPermissions.getOrDefault("tpa", false) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.needop_tpa",
                            "menu.tpatools.config.hover.needop_tpa",
                            "/tpatools configs needop tpa " + (!ModConfigs.commandPermissions.getOrDefault("tpa", false)),
                            tpaColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            class_124 homeColor = ModConfigs.commandPermissions.getOrDefault("home", false) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.needop_home",
                            "menu.tpatools.config.hover.needop_home",
                            "/tpatools configs needop home " + (!ModConfigs.commandPermissions.getOrDefault("home", false)),
                            homeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            class_124 graveColor = ModConfigs.commandPermissions.getOrDefault("grave", false) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.needop_grave",
                            "menu.tpatools.config.hover.needop_grave",
                            "/tpatools configs needop grave " + (!ModConfigs.commandPermissions.getOrDefault("grave", false)),
                            graveColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            class_124 backColor = ModConfigs.commandPermissions.getOrDefault("back", false) ?
                    class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.needop_back",
                            "menu.tpatools.config.hover.needop_back",
                            "/tpatools configs needop back " + (!ModConfigs.commandPermissions.getOrDefault("back", false)),
                            backColor,
                            true))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.tpawaittime", "- TPA Timeout Duration (tpawaittime)\n")
                    .method_27692(class_124.field_1068));

            int waitTime = ModConfigs.WAIT_SECONDS.getAsInt();
            class_124 waitColor = waitTime == 30 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime_30",
                            "menu.tpatools.home.hover.tpawaittime",
                            "/tpatools configs tpawaittime 30",
                            waitColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            waitColor = waitTime == 60 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime_60",
                            "menu.tpatools.home.hover.tpawaittime",
                            "/tpatools configs tpawaittime 60",
                            waitColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime",
                            "menu.tpatools.config.hover.tpawaittime",
                            "/tpatools configs tpawaittime ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.tpacdtime", "- TPA Cooldown Duration (tpacdtime)\n")
                    .method_27692(class_124.field_1068));

            int cdTime = (int) (ModConfigs.COOLDOWN_TIME.getAsLong() / 1000);
            class_124 cdColor = cdTime == 0 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_0",
                            "menu.tpatools.home.hover.tpacdtime",
                            "/tpatools configs tpacdtime 0",
                            cdColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            cdColor = cdTime == 10 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_10",
                            "menu.tpatools.home.hover.tpacdtime",
                            "/tpatools configs tpacdtime 10",
                            cdColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            cdColor = cdTime == 30 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_30",
                            "menu.tpatools.home.hover.tpacdtime",
                            "/tpatools configs tpacdtime 30",
                            cdColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            menu.method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime",
                            "menu.tpatools.config.hover.tpacdtime",
                            "/tpatools configs tpacdtime ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.homeinvitecdtime", "- Home Invite Cooldown Duration (homeinvitecdtime)\n")
                    .method_27692(class_124.field_1068));

            int homeInviteCDTime = ModConfigs.HOME_INVITE_COOLDOWN.getAsInt();
            class_124 homeCDColor = homeInviteCDTime == 0 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_0",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 0",
                            homeCDColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            homeCDColor = homeInviteCDTime == 10 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_10",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 10",
                            homeCDColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            homeCDColor = homeInviteCDTime == 30 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_30",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 30",
                            homeCDColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.homeinviteovertime", "- Home Invite Timeout Duration (homeinviteovertime)\n")
                    .method_27692(class_124.field_1068));

            int homeInviteOverTime = ModConfigs.HOME_INVITE_TIMEOUT.getAsInt();
            class_124 homeOTColor = homeInviteOverTime == 30 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_30",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 30",
                            homeOTColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            homeOTColor = homeInviteOverTime == 60 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_60",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 60",
                            homeOTColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            homeOTColor = homeInviteOverTime == 120 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_120",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 120",
                            homeOTColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            menu.method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            // 骑乘实体传送设置
            boolean allowRideTeleport = ModConfigs.ALLOW_TELEPORT_RIDE_ENTITY.getAsBoolean();
            class_124 rideColor = allowRideTeleport ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.branch.allowteleportrideentity",
                            "menu.tpatools.config.hover.allowteleportrideentity",
                            "/tpatools configs allowteleportrideentity",
                            class_124.field_1068,
                            true))
                    .method_10852(createI18nButton(allowRideTeleport ? "menu.tpatools.config.button.allowteleportrideentity_true" : "menu.tpatools.config.button.allowteleportrideentity_false",
                            "menu.tpatools.config.hover.allowteleportrideentity",
                            "/tpatools configs allowteleportrideentity " + (!allowRideTeleport),
                            rideColor,
                            true))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.rtpscope", "- RTP Scope (rtpscope)\n")
                    .method_27692(class_124.field_1068));

            int rtpScope = ModConfigs.RTP_SCOPE.getAsInt();
            class_124 rtpScopeColor = rtpScope == 10000 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_10000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 10000",
                            rtpScopeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            rtpScopeColor = rtpScope == 20000 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_20000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 20000",
                            rtpScopeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            rtpScopeColor = rtpScope == 50000 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_50000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 50000",
                            rtpScopeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            rtpScopeColor = rtpScope == 100000 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_100000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 100000",
                            rtpScopeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_custom",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.rtpcdtime", "- RTP Cooldown Time (rtpcdtime)\n")
                    .method_27692(class_124.field_1068));

            int rtpcdtime = ModConfigs.RTP_COOLDOWN_TIME.getAsInt();
            class_124 rtpcdtimeColor = rtpcdtime == 30 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_30",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 30",
                            rtpcdtimeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            rtpcdtimeColor = rtpcdtime == 60 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_60",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 60",
                            rtpcdtimeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            rtpcdtimeColor = rtpcdtime == 120 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_120",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 120",
                            rtpcdtimeColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            menu.method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_custom",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));

            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.setmaxwarpcount", "- Max Warp Count set (setmaxwarpcount)\n")
                    .method_27692(class_124.field_1068));
            int maxwarpcount = ModConfigs.MAX_WARP_COUNT.getAsInt();
            class_124 maxwarpcountColor = maxwarpcount == 1 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_1",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount 1",
                            maxwarpcountColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            maxwarpcountColor = maxwarpcount == 2 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_2",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount 2",
                            maxwarpcountColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            maxwarpcountColor = maxwarpcount == 3 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_3",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount 3",
                            maxwarpcountColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            maxwarpcountColor = maxwarpcount == 4 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_4",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount 4",
                            maxwarpcountColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            maxwarpcountColor = maxwarpcount == 5 ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_5",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount 5",
                            maxwarpcountColor,
                            true))
                    .method_10852(class_2561.method_43470(" "));
            menu.method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_custom",
                            "menu.tpatools.config.hover.setmaxwarpcount",
                            "/tpatools configs setmaxwarpcount ",
                            class_124.field_1080,
                            false))
                    .method_10852(class_2561.method_43470("\n"));


            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.branch.debug", "- Debug Mode (debug)\n")
                    .method_27692(class_124.field_1068));

            boolean debugEnabled = ModConfigs.isDebugEnabled();
            class_124 debugColor = debugEnabled ? class_124.field_1060 : class_124.field_1080;
            menu.method_10852(createI18nButton(debugEnabled ? "menu.tpatools.config.button.debugvalue.true" : "menu.tpatools.config.button.debugvalue.false",
                    "menu.tpatools.config.hover.debugvalue",
                    "/tpatools debug " + (!debugEnabled),
                    debugColor,
                    true));

            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showSetLanguageMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/setlanguage ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.setlanguage", "This setting is used to modify the hot-reload language feature of the TPATools mod.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.setlanguage", "- Default value: zh_cn (currently {})", ModConfigs.DEFAULT_LANGUAGE.get())
                            .method_27692(class_124.field_1080));

            // 按钮
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_1",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage zh_cn",
                            "zh_cn".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_2",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage en_us",
                            "en_us".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_3",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage fr_fr",
                            "fr_fr".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_4",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage pt_br",
                            "pt_br".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_5",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage es_es",
                            "es_es".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setlanguage_6",
                            "menu.tpatools.config.hover.setlanguage",
                            "/tpatools configs setlanguage zh_cn_cute",
                            "zh_cn_cute".equals(ModConfigs.DEFAULT_LANGUAGE.get()) ? class_124.field_1060 : class_124.field_1080,
                            true));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showSetMaxHomeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/setmaxhome ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.setmaxhome", "This setting controls the maximum number of homes allowed for all players on the server.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.setmaxhome", "- Default: 2 (currently: {})", ModConfigs.MAX_HOMES.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_2",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome 2",
                            2 == ModConfigs.MAX_HOMES.getAsInt() ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_3",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome 3",
                            3 == ModConfigs.MAX_HOMES.getAsInt() ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome_5",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome 5",
                            5 == ModConfigs.MAX_HOMES.getAsInt() ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxhome",
                            "menu.tpatools.config.hover.setmaxhome",
                            "/tpatools configs setmaxhome ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showNeedOpMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/needop ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.needop", "Used to specify whether certain commands require OP permission.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.needop", "- Default: tpa:false home:false grave:false back:false\n (currently set to tpa:{}, home:{}, grave:{}, back:{})",
                                    ModConfigs.commandPermissions.getOrDefault("tpa", false),
                                    ModConfigs.commandPermissions.getOrDefault("home", false),
                                    ModConfigs.commandPermissions.getOrDefault("grave", false),
                                    ModConfigs.commandPermissions.getOrDefault("back", false))
                            .method_27692(class_124.field_1080));

            // 按钮
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.needop_tpa",
                            "menu.tpatools.config.hover.needop_tpa",
                            "/tpatools configs needop tpa " + (!ModConfigs.commandPermissions.getOrDefault("tpa", false)),
                            ModConfigs.commandPermissions.getOrDefault("tpa", false) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.needop_home",
                            "menu.tpatools.config.hover.needop_home",
                            "/tpatools configs needop home " + (!ModConfigs.commandPermissions.getOrDefault("home", false)),
                            ModConfigs.commandPermissions.getOrDefault("home", false) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.needop_grave",
                            "menu.tpatools.config.hover.needop_grave",
                            "/tpatools configs needop grave " + (!ModConfigs.commandPermissions.getOrDefault("grave", false)),
                            ModConfigs.commandPermissions.getOrDefault("grave", false) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.needop_back",
                            "menu.tpatools.config.hover.needop_back",
                            "/tpatools configs needop back " + (!ModConfigs.commandPermissions.getOrDefault("back", false)),
                            ModConfigs.commandPermissions.getOrDefault("back", false) ? class_124.field_1060 : class_124.field_1080,
                            true));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showTPAWaitTimeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/tpawaittime ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.tpawaittime", "Sets the timeout duration for TPA requests.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.tpawaittime", "- Default: 30 (unit: seconds) (currently set to {} seconds)", ModConfigs.WAIT_SECONDS.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime_30",
                            "menu.tpatools.config.hover.tpawaittime",
                            "/tpatools configs tpawaittime 30",
                            30 == ModConfigs.WAIT_SECONDS.getAsInt() ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime_60",
                            "menu.tpatools.config.hover.tpawaittime",
                            "/tpatools configs tpawaittime 60",
                            60 == ModConfigs.WAIT_SECONDS.getAsInt() ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpawaittime",
                            "menu.tpatools.config.hover.tpawaittime",
                            "/tpatools configs tpawaittime ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showTPACDTimeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/tpacdtime ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.tpacdtime", "Sets the cooldown duration between TPA requests.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.tpacdtime", "- Default: 0 (unit: seconds) (currently set to {} seconds)", (ModConfigs.COOLDOWN_TIME.getAsLong() / 1000)))
                    .method_27692(class_124.field_1080);

            // 按钮
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_0",
                            "menu.tpatools.config.hover.tpacdtime",
                            "/tpatools configs tpacdtime 0",
                            0 == (ModConfigs.COOLDOWN_TIME.getAsLong() / 1000) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_10",
                            "menu.tpatools.config.hover.tpacdtime",
                            "/tpatools configs tpacdtime 10",
                            10 == (ModConfigs.COOLDOWN_TIME.getAsLong() / 1000) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime_30",
                            "menu.tpatools.config.hover.tpacdtime",
                            "/tpatools configs tpacdtime 30",
                            30 == (ModConfigs.COOLDOWN_TIME.getAsLong() / 1000) ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.tpacdtime",
                            "menu.tpatools.config.hover.tpacdtime",
                            "/tpatools configs tpacdtime ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showDebugMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/debug ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.debug", "Used to enable debug mode.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.debug_2", "Important note: This mode only toggles logging for this mod on the server. If you are an administrator but cannot view logs, please enable this cautiously.\n")
                            .method_27692(class_124.field_1061))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.debug", "- Default: false (currently set to {})", ModConfigs.isDebugEnabled()))
                    .method_27692(class_124.field_1080);

            // 按钮
            boolean debugEnabled = ModConfigs.isDebugEnabled();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.debugvalue.false",
                            "menu.tpatools.config.hover.debugvalue.false",
                            "/tpatools debug false",
                            !debugEnabled ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.debugvalue.true",
                            "menu.tpatools.config.hover.debugvalue.true",
                            "/tpatools debug true",
                            debugEnabled ? class_124.field_1060 : class_124.field_1080,
                            true));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showAllowTeleportRideEntityMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/allowteleportrideentity ======\n")
                    .method_27692(class_124.field_1065));
            // 骑乘实体传送设置
            boolean allowRideTeleport = ModConfigs.ALLOW_TELEPORT_RIDE_ENTITY.getAsBoolean();
            class_124 rideColor = allowRideTeleport ? class_124.field_1060 : class_124.field_1061;
            menu.method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.allowteleportrideentity",
                                    "This setting controls whether to teleport ridden entities with players when using /tpa.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.allowteleportrideentity",
                                    "- Default: false (currently set to %s)", allowRideTeleport)
                            .method_27692(class_124.field_1080))
                    .method_10852(createI18nButton(allowRideTeleport ? "menu.tpatools.config.button.allowteleportrideentity_true" : "menu.tpatools.config.button.allowteleportrideentity_false",
                            "menu.tpatools.config.hover.allowteleportrideentity",
                            "/tpatools configs allowteleportrideentity " + (!allowRideTeleport),
                            rideColor,
                            true));

            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showAboutMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");
            menu.method_10852(class_2561.method_43470("====== TPATools - about ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.about.main", "Thanx for using TPATools. Your translation maybe not complete.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.about.url.mcmod", "[MCMod Wiki Page]")
                            .method_27694(style -> style.method_10958(new class_2558(class_2558.class_2559.field_11749, "https://www.mcmod.cn/class/22216.html"))
                                    .method_10949(new class_2568(class_2568.class_5247.field_24342, ModUtils.translateWithFallback("menu.tpatools.about.hover.url.mcmod", "Click to open the MCMod Wiki Page.Only for Chinese players.")))
                            )
                            .method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.about.url.modrinth", "[Modrinth Page]")
                            .method_27694(style -> style.method_10958(new class_2558(class_2558.class_2559.field_11749, "https://modrinth.com/mod/tpatools"))
                                    .method_10949(new class_2568(class_2568.class_5247.field_24342, ModUtils.translateWithFallback("menu.tpatools.about.hover.url.modrinth", "Click to open the Modrinth Page.")))
                            )
                            .method_27692(class_124.field_1060))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.about.url.github", "[GitHub issue Page]")
                            .method_27694(style -> style.method_10958(new class_2558(class_2558.class_2559.field_11749, "https://github.com/kicobicn/TPATools/issues"))
                                    .method_10949(new class_2568(class_2568.class_5247.field_24342, ModUtils.translateWithFallback("menu.tpatools.about.hover.url.github", "Click to open the GitHub issue Page.")))
                            )
                            .method_27692(class_124.field_1063)
                    );

            menu.method_10852(class_2561.method_43470("\n===================")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showHomeInviteCDTimeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/homeinvitecdtime ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.homeinvitecdtime", "Sets the cooldown duration between home invite requests.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.homeinvitecdtime", "- Default: 0 (unit: seconds) (currently set to {} seconds)", ModConfigs.HOME_INVITE_COOLDOWN.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            int homeInviteCDTime = ModConfigs.HOME_INVITE_COOLDOWN.getAsInt();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_0",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 0",
                            0 == homeInviteCDTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_10",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 10",
                            10 == homeInviteCDTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime_30",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime 30",
                            30 == homeInviteCDTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinvitecdtime",
                            "menu.tpatools.config.hover.homeinvitecdtime",
                            "/tpatools configs homeinvitecdtime ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showHomeInviteOverTimeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/homeinviteovertime ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.homeinviteovertime", "Sets the timeout duration for home invite requests.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.homeinviteovertime", "- Default: 30 (unit: seconds) (currently set to {} seconds)", ModConfigs.HOME_INVITE_TIMEOUT.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            int homeInviteOverTime = ModConfigs.HOME_INVITE_TIMEOUT.getAsInt();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_30",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 30",
                            30 == homeInviteOverTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_60",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 60",
                            60 == homeInviteOverTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime_120",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime 120",
                            120 == homeInviteOverTime ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.homeinviteovertime",
                            "menu.tpatools.config.hover.homeinviteovertime",
                            "/tpatools configs homeinviteovertime ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showRTPScopeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/rtpscope ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.rtpscope", "Sets the radius for random teleportation.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.rtpscope", "- Default: 100000 (unit: blocks) (currently set to %d blocks)", ModConfigs.RTP_SCOPE.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            int rtpScope = ModConfigs.RTP_SCOPE.getAsInt();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_10000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 10000",
                            10000 == rtpScope ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_20000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 20000",
                            20000 == rtpScope ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_50000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 50000",
                            50000 == rtpScope ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_100000",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope 100000",
                            100000 == rtpScope ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpscope_custom",
                            "menu.tpatools.config.hover.rtpscope",
                            "/tpatools configs rtpscope ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showRTPCooldownTimeMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/rtpcooldown ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.rtpcdtime", "Sets the cooldown time for random teleportation.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.rtpcdtime", "- Default: 30 (unit: seconds) (currently set to {} seconds)", ModConfigs.RTP_COOLDOWN_TIME.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            int rtpcoolDown = ModConfigs.RTP_COOLDOWN_TIME.getAsInt();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_30",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 30",
                            30 == rtpcoolDown ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_60",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 60",
                            60 == rtpcoolDown ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_120",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime 120",
                            120 == rtpcoolDown ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.rtpcdtime_custom",
                            "menu.tpatools.config.hover.rtpcdtime",
                            "/tpatools configs rtpcdtime ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }

        public static void showMaxWarpCountMenu(class_3222 player) {
            class_5250 menu = class_2561.method_43470("");

            // 标题
            menu.method_10852(class_2561.method_43470("====== TPATools - setting/maxwarpcount ======\n")
                            .method_27692(class_124.field_1065))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.tips.setmaxwarpcount", "Sets the maximum number of warps.\n")
                            .method_27692(class_124.field_1068))
                    .method_10852(ModUtils.translateWithFallback("menu.tpatools.config.default.setmaxwarpcount", "- Default: 3 (currently set to {} warps)", ModConfigs.MAX_WARP_COUNT.getAsInt())
                            .method_27692(class_124.field_1080));

            // 按钮
            int maxWarpCount = ModConfigs.MAX_WARP_COUNT.getAsInt();
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_1",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount 1",
                            1 == maxWarpCount ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_2",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount 2",
                            2 == maxWarpCount ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_3",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount 3",
                            3 == maxWarpCount ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_4",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount 4",
                            4 == maxWarpCount ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_5",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount 5",
                            5 == maxWarpCount ? class_124.field_1060 : class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.config.button.setmaxwarpcount_custom",
                            "menu.tpatools.config.hover.maxwarpcount",
                            "/tpatools configs setmaxwarpcount ",
                            class_124.field_1080,
                            false));

            // 分割线
            menu.method_10852(class_2561.method_43470("\n=============================\n")
                    .method_27692(class_124.field_1065));

            player.method_43496(menu);
        }
    }

    public static void showWarpMenu(class_3222 player) {
        class_5250 menu = class_2561.method_43470("");
        // 标题
        menu.method_10852(class_2561.method_43470("====== TPATools - warp ======\n")
                        .method_27692(class_124.field_1065))
                .method_10852(ModUtils.translateWithFallback("menu.tpatools.warp.tip", "Warp point menu.\n")
                        .method_27692(class_124.field_1068));

        // 地标列表
        menu.method_10852(class_2561.method_43470(" "))
                .method_10852(createI18nButton("menu.tpatools.warp.button.warp_list",
                        "menu.tpatools.warp.hover.warp_list",
                        "/warp list",
                        class_124.field_1060,
                        true))
                .method_10852(class_2561.method_43470(" "));
        if (player.method_5687(2)) {
            menu.method_10852(class_2561.method_43470(" "))
                    .method_10852(createI18nButton("menu.tpatools.warp.button.setwarp",
                            "menu.tpatools.warp.hover.setwarp",
                            "/warp set ",
                            class_124.field_1060,
                            false))
                    .method_10852(class_2561.method_43470(" "));
        }

        // 分割线
        menu.method_10852(class_2561.method_43470("\n=============================\n")
                        .method_27692(class_124.field_1065));

        player.method_43496(menu);
    }

    public static void showWarpList(class_3222 player, int page) {
        
        if (WarpHandler.warpPoints.isEmpty()) {
            player.method_43496(ModUtils.translateWithFallback(
                    "command.tpatool.warp.no_warps", "No warp points available."));
            return;
        }

        List<String> warpNames = new ArrayList<>(WarpHandler.warpPoints.keySet());
        int pageSize = 5;
        int totalPages = (int) Math.ceil((double) warpNames.size() / pageSize);
        page = Math.max(0, Math.min(page, totalPages - 1));

        class_5250 menu = class_2561.method_43470("");

        // 标题
        menu.method_10852(class_2561.method_43470("====== TPATools - Warp/list ======\n")
                        .method_27692(class_124.field_1065))
                .method_10852(ModUtils.translateWithFallback("menu.tpatools.warp.title.warp_list", "        - Available Warp Points -\n")
                        .method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470("\n"));

        // 显示当前页的warp点
        int startIndex = page * pageSize;
        int endIndex = Math.min(startIndex + pageSize, warpNames.size());

        for (int i = startIndex; i < endIndex; i++) {
            String warpName = warpNames.get(i);
            WarpHandler.WarpPoint warp = WarpHandler.warpPoints.get(warpName);

            menu.method_10852(class_2561.method_43470("- " + warpName + "\n")
                    .method_27692(class_124.field_1068));

            String position = String.format("%s (x=%.2f, y=%.2f, z=%.2f)",
                    warp.dimension, warp.x, warp.y, warp.z);
            menu.method_10852(class_2561.method_43470("  " + position + "\n")
                    .method_27692(class_124.field_1080));

            // 按钮行
            class_5250 buttons = class_2561.method_43470("  ");
            buttons.method_10852(createI18nButton("menu.tpatools.warp.button.teleport",
                            "menu.tpatools.warp.hover.teleport",
                            "/warp tp " + warpName,
                            class_124.field_1060,
                            true))
                    .method_10852(class_2561.method_43470(" "));

            if (player.method_5687(2)) { // OP权限
                buttons.method_10852(createI18nButton("menu.tpatools.warp.button.remove",
                                "menu.tpatools.warp.hover.remove",
                                "/warp remove " + warpName,
                                class_124.field_1061,
                                true))
                        .method_10852(class_2561.method_43470(" "));
            }

            menu.method_10852(buttons).method_10852(class_2561.method_43470("\n"));
        }

        // 分页系统
        if (totalPages > 1) {
            menu.method_10852(class_2561.method_43470("=============================\n")
                    .method_27692(class_124.field_1065));

            class_5250 pagination = class_2561.method_43470(" ");
            pagination.method_10852(createI18nButton("menu.tpatools.warp.button.previouspage",
                            "menu.tpatools.warp.hover.previouspage",
                            "/warp list page " + Math.max(0, page - 1),
                            class_124.field_1080,
                            true))
                    .method_10852(class_2561.method_43470(" - " + (page + 1) + "/" + totalPages + " - "))
                    .method_10852(createI18nButton("menu.tpatools.warp.button.nextpage",
                            "menu.tpatools.warp.hover.nextpage",
                            "/warp list page " + Math.min(totalPages - 1, page + 1),
                            class_124.field_1080,
                            true));

            menu.method_10852(pagination).method_10852(class_2561.method_43470("\n"));
        } else {
            menu.method_10852(class_2561.method_43470("=============================\n")
                    .method_27692(class_124.field_1065));
        }

        player.method_43496(menu);
    }

    public static class_5250 createButton(String text, String hoverText, String command, class_124 color, boolean isClickable) {
        class_5250 button = class_2561.method_43470(text)
                .method_27694(style -> {
                    style = style.method_10977(color);
                    if (isClickable) {
                        style = style.method_10958(new class_2558(class_2558.class_2559.field_11750, command));
                    } else {
                        style = style.method_10958(new class_2558(class_2558.class_2559.field_11745, command));
                    }
                    style = style.method_10949(new class_2568(class_2568.class_5247.field_24342,
                            class_2561.method_43470(hoverText)));
                    return style;
                });
        return button;
    }

    public static class_5250 createI18nButton(String translationKey, String hoverTranslationKey, String command, class_124 color, boolean isClickable, Object... args) {
        class_5250 textComponent = ModUtils.translateWithFallback(translationKey, translationKey, args);
        String hoverText = ModUtils.translateWithFallback(hoverTranslationKey, hoverTranslationKey, args).getString();
        return createButton(textComponent.getString(), hoverText, command, color, isClickable);
    }
    public static class_5250 createI18nButtonWithHoverArgs(String translationKey, String hoverTranslationKey, String command, class_124 color, boolean isClickable, Object[] args, Object[] hoverArgs) {
        class_5250 textComponent = ModUtils.translateWithFallback(translationKey, translationKey, args);
        String hoverText = ModUtils.translateWithFallback(hoverTranslationKey, hoverTranslationKey, hoverArgs).getString();
        return createButton(textComponent.getString(), hoverText, command, color, isClickable);
    }
}