package com.kicobicn.TPATools.chat;

import com.kicobicn.TPATools.config.ModConfigs;
import com.kicobicn.TPATools.util.ModUtils;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5250;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.network.chat.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatHandler {

    // 修改正则表达式匹配 &数字 模式 (例如 &1)
    private static final Pattern ITEM_PATTERN = Pattern.compile("&(\\d)");

    public static void registerEvents() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            try {
                String originalMessage = message.method_46291().getString();
                ModConfigs.DebugLog.info("Processing chat message from {}: {}", sender.method_5477().getString(), originalMessage);

                // 处理提到玩家功能（副作用：发送标题提示+音效给被@的玩家，返回着色后的文本）
                String mentionedMessage = processMentions(originalMessage, sender);

                // 处理展示物品功能
                class_5250 finalMessage = processItemDisplay(class_2561.method_43470(mentionedMessage), sender);

                // 检查消息是否被物品展示功能修改过
                if (!finalMessage.getString().equals(originalMessage)) {
                    // 替换聊天格式：<玩家名> 消息内容
                    class_5250 chatMessage = class_2561.method_43470("<")
                            .method_10852(sender.method_5476())
                            .method_10852(class_2561.method_43470("> "))
                            .method_10852(finalMessage);

                    // 取消原始消息，手动广播修改后的消息
                    sender.method_5682().execute(() -> {
                        sender.method_5682().method_3760().method_14571().forEach(p ->
                                p.method_43496(chatMessage)
                        );
                    });
                    return false;
                }

                return true;
            } catch (Exception e) {
                ModConfigs.DebugLog.error("Error processing chat message: {}", e.getMessage(), e);
                return true;
            }
        });
    }

    /**
     * 处理提到玩家功能 (返回Component以更好地处理颜色代码)
     */
    private static String processMentions(String message, class_3222 sender) {
        // 获取所有在线玩家
        var onlinePlayers = sender.method_5682().method_3760().method_14571();
        String processedMessage = message; // 初始化为原消息

        for (class_3222 target : onlinePlayers) {
            String playerName = target.method_5477().getString();

            // 跳过自己
            if (target.method_5667().equals(sender.method_5667())) {
                continue;
            }

            // 如果消息中包含玩家名（不区分大小写）
            if (message.toLowerCase().contains(playerName.toLowerCase())) {
                ModConfigs.DebugLog.info("Player {} mentioned {}", sender.method_5477().getString(), playerName);

                // 将玩家名标色
                processedMessage = processedMessage.replaceAll("(?i)" + java.util.regex.Pattern.quote(playerName),
                        class_124.field_1075 + playerName + class_124.field_1070);

                // 使用 Title 数据包来实现居中大标题提示的效果
                class_5904 titlePacket =
                        new class_5904(
                                ModUtils.translateWithFallback(
                                        "command.tpatool.chat.mention",
                                        "%s mentioned you",
                                        sender.method_5477()
                                ).method_27692(class_124.field_1075)
                        );
                // 设置标题显示时间、淡入淡出时间
                class_5905 timesPacket =
                        new class_5905(10, 40, 10);
                target.field_13987.method_14364(timesPacket);
                target.field_13987.method_14364(titlePacket);

                // 播放音效
                target.method_17356(class_3417.field_14622.comp_349(), class_3419.field_15248, 1.0F, 1.0F);
            }
        }

        // 特别处理：如果消息中包含自己的名字，也将其设置为青色
        String senderName = sender.method_5477().getString();
        if (processedMessage.contains(senderName)) {
            processedMessage = processedMessage.replaceAll("(?i)" + java.util.regex.Pattern.quote(senderName),
                    class_124.field_1075 + senderName + class_124.field_1070);
        }

        return processedMessage;
    }

    /**
     * 处理展示物品功能
     */
    private static class_5250 processItemDisplay(class_2561 originalComponent, class_3222 player) {
        String message = originalComponent.getString();
        List<Object> messageParts = new ArrayList<>();
        Matcher matcher = ITEM_PATTERN.matcher(message);
        int lastIndex = 0;

        while (matcher.find()) {
            // 添加前面的普通文本
            if (matcher.start() > lastIndex) {
                messageParts.add(message.substring(lastIndex, matcher.start()));
            }

            // 处理物品占位符
            int slot = Integer.parseInt(matcher.group(1)) - 1; // 转换为0-8的索引
            if (slot >= 0 && slot <= 8) {
                class_1799 itemStack = player.method_31548().method_5438(slot);
                if (!itemStack.method_7960()) {
                    // 添加物品组件
                    messageParts.add(createItemComponent(itemStack));
                    ModConfigs.DebugLog.info("Replaced &{} with item: {}", slot + 1, itemStack.method_7954().getString());
                } else {
                    // 槽位为空，保留原文本
                    messageParts.add(matcher.group(0));
                    ModConfigs.DebugLog.info("Slot {} is empty, keeping original text", slot + 1);
                }
            } else {
                // 无效槽位，保留原文本
                messageParts.add(matcher.group(0));
                ModConfigs.DebugLog.info("Invalid slot {}, keeping original text", slot + 1);
            }

            lastIndex = matcher.end();
        }

        // 添加剩余的文本
        if (lastIndex < message.length()) {
            messageParts.add(message.substring(lastIndex));
        }

        // 构建最终的消息组件
        class_5250 finalMessage = class_2561.method_43470("");
        for (Object part : messageParts) {
            if (part instanceof String) {
                finalMessage.method_10852(class_2561.method_43470((String) part));
            } else if (part instanceof class_5250) {
                finalMessage.method_10852((class_5250) part);
            }
        }

        return finalMessage;
    }

    //展示物品组件
    private static class_5250 createItemComponent(class_1799 itemStack) {
        // 获取物品原有的显示名称和颜色（保持其原始样式）
        class_5250 itemDisplayName = itemStack.method_7954().method_27661();

        // 构建组件：外括号为金色，物品名称为其原始颜色
        return class_2561.method_43470("[") // 左外括号，金色
                .method_27692(class_124.field_1065)
                .method_10852(itemDisplayName) // 物品名称，保持原色
                .method_10852(class_2561.method_43470("]").method_27692(class_124.field_1065));
    }
}