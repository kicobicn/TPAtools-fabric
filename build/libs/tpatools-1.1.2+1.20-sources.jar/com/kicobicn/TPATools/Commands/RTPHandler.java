package com.kicobicn.TPATools.Commands;

import com.kicobicn.TPATools.config.ModConfigs;
import com.kicobicn.TPATools.util.ModUtils;
import com.mojang.brigadier.CommandDispatcher;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3610;
import net.minecraft.class_7157;

public class RTPHandler {
    
    // 冷却时间管理
    private static final Map<UUID, Long> rtpCooldowns = new HashMap<>();
    private static final Random random = new Random();

    public static void onRegisterCommands(CommandDispatcher<class_2168> dispatcher, class_7157 buildContext) {
        dispatcher.register(
                class_2170.method_9247("rtp")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "rtp"))
                        .executes(context -> {
                            try {
                                class_3222 player = context.getSource().method_9207();
                                return executeRTP(player);
                            } catch (Exception e) {
                                ModConfigs.DebugLog.error("Unexpected error in /rtp: ", e);
                                context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                return 0;
                            }
                        })
        );
    }

    /**
     * 执行RTP传送
     */
    private static int executeRTP(class_3222 player) {
        UUID playerUUID = player.method_5667();
        
        // 检查冷却时间
        if (isOnCooldown(playerUUID)) {
            long remainingTime = getRemainingCooldown(playerUUID);
            player.method_43496(
                    ModUtils.translateWithFallback(
                            "command.tpatool.rtp.cooldown", 
                            "RTP is on cooldown. Please wait %d seconds.", 
                            remainingTime
                    )
            );
            return 0;
        }

        // 开始寻找安全位置
        player.method_43496(
                ModUtils.translateWithFallback(
                        "command.tpatool.rtp.searching", 
                        "Searching for a safe location..."
                )
        );

        class_3218 world = (class_3218) player.method_37908();
        // 以世界原点 (0,0) 为中心进行随机传送
        class_2338 safePos = findSafeLocation(world, 0, 0);
        
        if (safePos == null) {
            player.method_43496(
                    ModUtils.translateWithFallback(
                            "command.tpatool.rtp.failed", 
                            "Failed to find a safe location after %d attempts. Please try again.", 
                            ModConfigs.RTP_MAX_ATTEMPTS.getAsInt()
                    )
            );
            return 0;
        }

        // 传送玩家
        player.method_14251(world, safePos.method_10263() + 0.5, safePos.method_10264() + 1, safePos.method_10260() + 0.5, 
                          player.method_36454(), player.method_36455());
        
        // 设置冷却时间
        setCooldown(playerUUID);
        
        player.method_43496(
                ModUtils.translateWithFallback(
                        "command.tpatool.rtp.success", 
                        "Successfully teleported to X: %d, Y: %d, Z: %d", 
                        safePos.method_10263(), safePos.method_10264(), safePos.method_10260()
                ).method_27692(class_124.field_1060)
        );
        
        ModConfigs.DebugLog.info("Player {} used RTP to X: {}, Y: {}, Z: {}", 
                                player.method_5477().getString(), safePos.method_10263(), safePos.method_10264(), safePos.method_10260());
        
        return 1;
    }

    /**
     * 寻找安全位置
     */
    private static class_2338 findSafeLocation(class_3218 world, int centerX, int centerZ) {
        int scope = ModConfigs.RTP_SCOPE.getAsInt();
        int maxAttempts = ModConfigs.RTP_MAX_ATTEMPTS.getAsInt();
        int minY = ModConfigs.RTP_MIN_Y.getAsInt();
        int maxY = ModConfigs.RTP_MAX_Y.getAsInt();
        
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            // 在范围内随机选择位置
            int x = centerX + random.nextInt(scope * 2) - scope;
            int z = centerZ + random.nextInt(scope * 2) - scope;
            
            // 从最高点开始向下寻找安全位置
            class_2338.class_2339 pos = new class_2338.class_2339(x, maxY, z);
            
            // 向下寻找地面
            while (pos.method_10264() > minY) {
                class_2680 blockState = world.method_8320(pos);
                class_2680 blockBelow = world.method_8320(pos.method_10074());
                class_2680 blockAbove = world.method_8320(pos.method_10084());
                
                // 检查当前位置是否安全
                if (isSafePosition(world, pos, blockState, blockBelow, blockAbove)) {
                    return pos.method_10062();
                }
                
                pos.method_10100(0, -1, 0);
            }
        }
        
        return null; // 未找到安全位置
    }

    /**
     * 检查位置是否安全
     */
    private static boolean isSafePosition(class_3218 world, class_2338 pos, class_2680 blockState, 
                                         class_2680 blockBelow, class_2680 blockAbove) {
        // 检查是否在有效Y范围内
        if (pos.method_10264() < ModConfigs.RTP_MIN_Y.getAsInt() || pos.method_10264() > ModConfigs.RTP_MAX_Y.getAsInt()) {
            return false;
        }
        
        // 检查当前位置是否可站立（非液体、非危险方块）
        if (!blockBelow.method_51366() || blockBelow.method_27852(class_2246.field_10164) || 
            blockBelow.method_27852(class_2246.field_10092) || blockBelow.method_27852(class_2246.field_10036) ||
            blockBelow.method_27852(class_2246.field_22089) || blockBelow.method_27852(class_2246.field_10029)) {
            return false;
        }
        
        // 检查当前位置是否可站立（非液体）
        class_3610 fluidState = blockState.method_26227();
        if (!fluidState.method_15769()) {
            return false;
        }
        
        // 检查上方是否有足够空间（至少2格高）
        if (!blockAbove.method_26215() || !world.method_8320(pos.method_10086(2)).method_26215()) {
            return false;
        }
        
        // 检查当前位置是否安全（非危险方块）
        if (blockState.method_27852(class_2246.field_10164) || blockState.method_27852(class_2246.field_10092) ||
            blockState.method_27852(class_2246.field_10036) || blockState.method_27852(class_2246.field_22089) ||
            blockState.method_27852(class_2246.field_10029) || blockState.method_27852(class_2246.field_16999)) {
            return false;
        }
        
        return true;
    }

    /**
     * 检查玩家是否在冷却中
     */
    private static boolean isOnCooldown(UUID playerUUID) {
        if (!rtpCooldowns.containsKey(playerUUID)) {
            return false;
        }
        
        long lastUsed = rtpCooldowns.get(playerUUID);
        long cooldownTime = ModConfigs.RTP_COOLDOWN_TIME.getAsInt() * 1000L; // 转换为毫秒
        return System.currentTimeMillis() - lastUsed < cooldownTime;
    }

    /**
     * 获取剩余冷却时间（秒）
     */
    private static long getRemainingCooldown(UUID playerUUID) {
        if (!rtpCooldowns.containsKey(playerUUID)) {
            return 0;
        }
        
        long lastUsed = rtpCooldowns.get(playerUUID);
        long cooldownTime = ModConfigs.RTP_COOLDOWN_TIME.getAsInt() * 1000L;
        long elapsed = System.currentTimeMillis() - lastUsed;
        long remaining = cooldownTime - elapsed;
        
        return Math.max(0, (remaining + 999) / 1000); // 向上取整到秒
    }

    /**
     * 设置冷却时间
     */
    private static void setCooldown(UUID playerUUID) {
        rtpCooldowns.put(playerUUID, System.currentTimeMillis());
    }

    /**
     * 清除冷却时间（用于调试或重置）
     */
    public static void clearCooldown(UUID playerUUID) {
        rtpCooldowns.remove(playerUUID);
    }

    /**
     * 获取所有冷却中的玩家
     */
    public static Map<UUID, Long> getCooldowns() {
        return new HashMap<>(rtpCooldowns);
    }
}