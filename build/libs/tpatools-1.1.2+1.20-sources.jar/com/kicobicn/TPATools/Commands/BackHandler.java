package com.kicobicn.TPATools.Commands;

import com.kicobicn.TPATools.config.ModConfigs;
import com.kicobicn.TPATools.util.ModUtils;
import com.mojang.brigadier.CommandDispatcher;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7924;

public class BackHandler {
    private static final Map<UUID, PlayerPosition> previousPositions = new HashMap<>();

    public static class PlayerPosition {
        public class_2960 dimension;
        public final double x, y, z;
        public final float yRot, xRot;

        public PlayerPosition(class_3218 level, double x, double y, double z, float yRot, float xRot) {
            this.dimension = level.method_27983().method_29177();
            this.x = x;
            this.y = y;
            this.z = z;
            this.yRot = yRot;
            this.xRot = xRot;
        }
    }

    public static void onRegisterCommands(CommandDispatcher<class_2168> dispatcher, class_7157 buildContext) {

        dispatcher.register(
                class_2170.method_9247("back")
                        .requires(source -> ModConfigs.checkCommandPermission(source, "back"))
                        .executes(context -> {
                            try {
                                class_3222 player = context.getSource().method_9207();
                                ModConfigs.DebugLog.info("Executing /back command for player: {}", player.method_5477().getString());
                                return teleportBack(player);
                            } catch (Exception e) {
                                ModConfigs.DebugLog.error("Unexpected error in /back command: ", e);
                                context.getSource().method_9213(class_2561.method_43470("An unexpected error occurred."));
                                return 0;
                            }
                        })
        );
    }

    public static void recordPosition(class_3222 player) {
        previousPositions.put(player.method_5667(), new PlayerPosition(
                player.method_51469(),
                player.method_23317(), player.method_23318(), player.method_23321(),
                player.method_36454(), player.method_36455()
        ));
        ModConfigs.DebugLog.log("Recorded position for {}: dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), player.method_51469().method_27983().method_29177(),
                player.method_23317(), player.method_23318(), player.method_23321());
    }

    private static int teleportBack(class_3222 player) {
        PlayerPosition pos = previousPositions.get(player.method_5667());
        if (pos == null) {
            player.method_43496(ModUtils.translateWithFallback(
                    "command.tpatool.back.no_position", "No previous position recorded!"
            ));
            return 0;
        }
        class_3218 level = player.method_5682().method_3847(class_5321.method_29179(
                class_7924.field_41223, pos.dimension));
        if (level == null) {
            player.method_43496(ModUtils.translateWithFallback(
                    "command.tpatool.back.invalid_dimension", "Invalid dimension for previous position!"
            ));
            previousPositions.remove(player.method_5667());
            return 0;
        }
        recordPosition(player);
        // 使用支持骑乘链和拴绳链的传送方法
        ModUtils.teleportWithAllChains(player, level, pos.x, pos.y, pos.z, pos.yRot, pos.xRot);
            player.method_43496(ModUtils.translateWithFallback(
                "command.tpatool.back.success", "Teleported to previous position."
        ));
        ModConfigs.DebugLog.info("Player {} teleported back to dimension={}, x={}, y={}, z={}",
                player.method_5477().getString(), pos.dimension, pos.x, pos.y, pos.z);
        return 1;
    }
}