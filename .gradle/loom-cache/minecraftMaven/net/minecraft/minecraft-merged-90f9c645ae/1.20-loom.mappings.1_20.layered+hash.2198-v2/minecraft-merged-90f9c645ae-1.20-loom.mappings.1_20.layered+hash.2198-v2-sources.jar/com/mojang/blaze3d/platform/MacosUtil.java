package com.mojang.blaze3d.platform;

import ca.weblite.objc.Client;
import ca.weblite.objc.NSObject;
import com.sun.jna.Pointer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.server.packs.resources.IoSupplier;
import org.lwjgl.glfw.GLFWNativeCocoa;

@Environment(EnvType.CLIENT)
public class MacosUtil {
	private static final int NS_FULL_SCREEN_WINDOW_MASK = 16384;

	public static void toggleFullscreen(long l) {
		getNsWindow(l).filter(MacosUtil::isInKioskMode).ifPresent(MacosUtil::toggleFullscreen);
	}

	private static Optional<NSObject> getNsWindow(long l) {
		long m = GLFWNativeCocoa.glfwGetCocoaWindow(l);
		return m != 0L ? Optional.of(new NSObject(new Pointer(m))) : Optional.empty();
	}

	private static boolean isInKioskMode(NSObject nSObject) {
		return ((Long)nSObject.sendRaw("styleMask", new Object[0]) & 16384L) == 16384L;
	}

	private static void toggleFullscreen(NSObject nSObject) {
		nSObject.send("toggleFullScreen:", new Object[]{Pointer.NULL});
	}

	public static void loadIcon(IoSupplier<InputStream> ioSupplier) throws IOException {
		InputStream inputStream = ioSupplier.get();

		try {
			String string = Base64.getEncoder().encodeToString(inputStream.readAllBytes());
			Client client = Client.getInstance();
			Object object = client.sendProxy("NSData", "alloc", new Object[0]).send("initWithBase64Encoding:", new Object[]{string});
			Object object2 = client.sendProxy("NSImage", "alloc", new Object[0]).send("initWithData:", new Object[]{object});
			client.sendProxy("NSApplication", "sharedApplication", new Object[0]).send("setApplicationIconImage:", new Object[]{object2});
		} catch (Throwable var7) {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (Throwable var6) {
					var7.addSuppressed(var6);
				}
			}

			throw var7;
		}

		if (inputStream != null) {
			inputStream.close();
		}
	}
}
